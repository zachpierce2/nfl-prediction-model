import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import pandas as pd
from data_layer import *
from odds import normalize

class DataLayerTests(unittest.TestCase):
    def setUp(self):
        self.cutoff='2026-11-15T17:00:00Z'
        self.games=pd.DataFrame([dict(game_id='2026_11_SEA_SF',home_team='SF',away_team='SEA',kickoff_utc=utc('2026-11-15T21:00:00Z'))])
        self.q=pd.DataFrame(columns=QB_COLS);self.i=pd.DataFrame(columns=INJ_COLS);self.c=pd.DataFrame(columns=COV_COLS)
    def qb(self,qid='starter',prob='1',stamp='2026-11-15T16:00:00Z',batch='a'):
        return dict(zip(QB_COLS,['2026_11_SEA_SF','SF',batch,qid,prob,stamp,stamp,'https://example.org/report']))
    def injury(self,prob='0',snap='.8'):
        return dict(zip(INJ_COLS,['2026_11_SEA_SF','SF','player','T',prob,snap,'2026-11-15T16:00:00Z','2026-11-15T16:00:00Z','https://example.org/report']))
    def coverage(self):
        return dict(zip(COV_COLS,['2026_11_SEA_SF','SF','true','2026-11-15T16:00:00Z','2026-11-15T16:00:00Z','https://example.org/report']))
    def test_missing_is_unknown(self):
        f,_=availability(self.games,self.q,self.i,self.c,self.cutoff)
        self.assertTrue(f.missing_snap_equivalents_OL.isna().all())
        self.assertTrue(f.qb_status.eq('missing').all())
    def test_qb_distribution_and_latest_batch(self):
        q=pd.DataFrame([self.qb(),self.qb('starter','.7','2026-11-15T16:30:00Z','b'),self.qb('backup','.3','2026-11-15T16:30:00Z','b')])
        f,s=availability(self.games,q,self.i,self.c,self.cutoff)
        self.assertEqual(len(s),2);self.assertAlmostEqual(f.iloc[0].qb_max_start_probability,.7)
    def test_incomplete_qb_distribution_blocks(self):
        with self.assertRaises(ValueError): availability(self.games,pd.DataFrame([self.qb(prob='.8')]),self.i,self.c,self.cutoff)
    def test_future_information_withheld(self):
        f,_=availability(self.games,pd.DataFrame([self.qb(stamp='2026-11-15T18:00:00Z')]),self.i,self.c,self.cutoff)
        self.assertEqual(f.iloc[0].qb_status,'missing')
    def test_injury_weighting_and_coverage(self):
        f,_=availability(self.games,self.q,pd.DataFrame([self.injury()]),pd.DataFrame([self.coverage()]),self.cutoff)
        self.assertAlmostEqual(f.iloc[0].missing_snap_equivalents_OL,.8)
        self.assertEqual(f.iloc[0].missing_snap_equivalents_DB,0)
        self.assertTrue(pd.isna(f.iloc[1].missing_snap_equivalents_OL))
    def test_partial_injuries_do_not_claim_healthy_positions(self):
        f,_=availability(self.games,self.q,pd.DataFrame([self.injury()]),self.c,self.cutoff)
        self.assertEqual(f.iloc[0].injury_status,'partial')
        self.assertTrue(pd.isna(f.iloc[0].missing_snap_equivalents_DB))
    def test_invalid_inputs(self):
        for value in ['nan','inf','1.5','-.1']:
            with self.assertRaises(ValueError): availability(self.games,self.q,pd.DataFrame([self.injury(prob=value)]),self.c,self.cutoff)
    def test_bad_timestamps_and_wrong_team(self):
        q=self.qb();q['recorded_at_utc']='2026-11-15T15:00:00Z'
        with self.assertRaises(ValueError): availability(self.games,pd.DataFrame([q]),self.i,self.c,self.cutoff)
        q=self.qb();q['team']='KC'
        with self.assertRaises(ValueError): availability(self.games,pd.DataFrame([q]),self.i,self.c,self.cutoff)
        q=self.qb();q['recorded_at_utc']='2026-11-15 16:00'
        with self.assertRaises(ValueError): availability(self.games,pd.DataFrame([q]),self.i,self.c,self.cutoff)
    def event(self):
        return dict(id='fixture-only',home_team='San Francisco 49ers',away_team='Seattle Seahawks',commence_time='2026-11-15T21:00:00Z',bookmakers=[dict(key='fixture_book',last_update='2026-11-15T16:59:00Z',markets=[dict(key='spreads',outcomes=[dict(name='San Francisco 49ers',point=-3,price=-110),dict(name='Seattle Seahawks',point=3,price=-110)])])])
    def capture(self,root):
        p=root/'capture';p.mkdir();raw=json.dumps([self.event()]).encode()
        (p/'provider_response.json').write_bytes(raw)
        (p/'capture.json').write_text(json.dumps(dict(captured_at_utc=self.cutoff,response_sha256=hashlib.sha256(raw).hexdigest())))
        return p
    def test_archive_is_idempotent_and_preserves_price(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p=self.capture(root)
            archive_capture(p,root/'archive');archive_capture(p,root/'archive')
            with sqlite3.connect(root/'archive/odds.sqlite') as db:
                self.assertEqual(db.execute('SELECT count(*) FROM captures').fetchone()[0],1)
                self.assertEqual(db.execute('SELECT count(*) FROM quotes').fetchone()[0],2)
                self.assertEqual(db.execute("SELECT line FROM quotes WHERE side='home'").fetchone()[0],-3)
            (p/'provider_response.json').write_text('[]')
            with self.assertRaises(ValueError): archive_capture(p,root/'archive')
    def test_nonfinite_and_invalid_odds_rejected(self):
        for bad in [float('nan'),float('inf'),3.1]:
            e=self.event();e['bookmakers'][0]['markets'][0]['outcomes'][0]['point']=bad
            q,rejected=normalize([e],self.cutoff)
            self.assertTrue(q.empty);self.assertTrue(rejected)
    def test_complete_pipeline_without_credentials(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p=self.capture(root);inp=root/'inputs';inp.mkdir()
            for name,cols in [('qb_scenarios',QB_COLS),('injuries',INJ_COLS),('injury_coverage',COV_COLS)]: pd.DataFrame(columns=cols).to_csv(inp/(name+'.csv'),index=False)
            sp=root/'schedule.csv'
            pd.DataFrame([dict(game_id='2026_11_SEA_SF',home_team='SF',away_team='SEA',gameday='2026-11-15',gametime='16:00')]).to_csv(sp,index=False)
            with patch('data_layer.datetime') as clock:
                clock.now.return_value=datetime(2026,11,15,17,1,tzinfo=timezone.utc)
                run(SimpleNamespace(capture=p,archive=root/'archive',inputs=inp,out=root/'output',schedule=sp))
            m=json.loads((root/'output/manifest.json').read_text())
            self.assertEqual(m['ready_teams'],0);self.assertEqual(m['teams'],2)
            self.assertTrue((root/'output/qb_scenarios_to_fill.csv').exists())
    def test_old_player_update_does_not_override_new(self):
        old=self.injury();new=self.injury(prob='1');new['recorded_at_utc']='2026-11-15T16:30:00Z'
        cov=self.coverage();cov['recorded_at_utc']='2026-11-15T16:30:00Z'
        f,_=availability(self.games,self.q,pd.DataFrame([new,old]),pd.DataFrame([cov]),self.cutoff)
        self.assertEqual(f.iloc[0].missing_snap_equivalents_OL,0)
    def test_postkickoff_reports_withheld(self):
        f,_=availability(self.games,pd.DataFrame([self.qb(stamp='2026-11-15T21:01:00Z')]),self.i,self.c,self.cutoff)
        self.assertEqual(f.iloc[0].qb_status,'missing')
    def test_game_join_preserves_missingness(self):
        f,_=availability(self.games,self.q,self.i,self.c,self.cutoff)
        g=game_features(self.games,f)
        self.assertFalse(g.iloc[0].availability_complete)
        self.assertTrue(pd.isna(g.iloc[0].missing_snap_equivalents_OL_diff))
    def test_late_player_update_invalidates_coverage(self):
        inj=self.injury();inj['recorded_at_utc']='2026-11-15T16:30:00Z'
        f,_=availability(self.games,self.q,pd.DataFrame([inj]),pd.DataFrame([self.coverage()]),self.cutoff)
        self.assertEqual(f.iloc[0].injury_status,'partial')
    def test_schedule_match_rejects_wrong_game(self):
        q,_=normalize([self.event()],self.cutoff)
        self.assertEqual(match(q,self.games).iloc[0].game_id,'2026_11_SEA_SF')
        games=self.games.copy();games['away_team']='KC'
        with self.assertRaises(ValueError): match(q,games)
    def test_rams_schedule_alias(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'schedule.csv'
            pd.DataFrame([dict(game_id='rams_fixture',home_team='LA',away_team='SEA',gameday='2026-11-15',gametime='16:00')]).to_csv(p,index=False)
            games=schedule(p)
            q,_=normalize([self.event()],self.cutoff);q['home_team']='LAR'
            self.assertEqual(match(q,games).iloc[0].game_id,'rams_fixture')
    def test_unmatched_does_not_drop_valid_event(self):
        q,_=normalize([self.event()],self.cutoff)
        bad=q.copy();bad['event_id']='unmatched_fixture';bad['home_team']='KC'
        result=match(pd.concat([q,bad],ignore_index=True),self.games,quarantine=True)
        self.assertEqual(len(result),2)
        self.assertEqual(len(result.attrs['unmatched_events']),1)
        self.assertEqual(result.attrs['unmatched_events'][0]['reason'],'no_schedule_match')
    def test_ambiguous_events_are_not_guessed(self):
        q,_=normalize([self.event()],self.cutoff)
        result=match(q,pd.concat([self.games,self.games],ignore_index=True),quarantine=True)
        self.assertTrue(result.empty)
        self.assertEqual(result.attrs['unmatched_events'][0]['reason'],'ambiguous_schedule_match')
    def test_no_matching_games_pipeline(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p=self.capture(root);sp=root/'schedule.csv'
            pd.DataFrame([dict(game_id='other_fixture',home_team='KC',away_team='SEA',gameday='2026-11-15',gametime='16:00')]).to_csv(sp,index=False)
            with patch('data_layer.datetime') as clock:
                clock.now.return_value=datetime(2026,11,15,17,1,tzinfo=timezone.utc)
                run(SimpleNamespace(capture=p,archive=root/'archive',inputs=root/'absent_inputs',out=root/'output',schedule=sp))
            m=json.loads((root/'output/manifest.json').read_text())
            self.assertEqual(m['status'],'NO_MATCHED_UPCOMING_GAMES')
            self.assertEqual(m['matched_quote_rows'],0)
            self.assertEqual(m['unmatched_events'],1)
            self.assertTrue(pd.read_csv(root/'output/availability_features.csv').empty)
            self.assertEqual(len(json.loads((root/'output/unmatched_events.json').read_text())),1)

if __name__=='__main__': unittest.main()
