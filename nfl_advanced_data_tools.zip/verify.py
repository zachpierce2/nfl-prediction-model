"""Detect changes to the distributed data tools before execution."""
import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'checksums.json').read_text())
for name,digest in manifest.items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('Checksum mismatch: '+name)
print('Data tools checksums verified.')
