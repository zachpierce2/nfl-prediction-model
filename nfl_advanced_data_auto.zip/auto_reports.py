"""Prospective nflverse reports. Raw statuses and depth candidates, never invented probabilities."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import urllib.request
import pandas as pd
from data_layer import utc, schedule, GROUPS

ROOT='https://github.com/nflverse/nflverse-data/releases/download/'
ALIASES={'LA':'LAR','STL':'LAR','OAK':'LV','SD':'LAC'}
DEPTH_REQUIRED={'dt','team','gsis_id','player_name','pos_abb','pos_rank'}
INJ_REQUIRED={'season','week','team','gsis_id','position','full_name','report_status','practice_status'}
SNAP_REQUIRED={'game_id','pfr_player_id','team','offense_pct','defense_pct','st_pct'}

def canon(frame):
    f=frame.copy()
    if 'team' in f:f['team']=f.team.replace(ALIASES)
    return f

def read_csv(path):
    return pd.read_csv(path,keep_default_na=False,dtype=str)

def require(f,columns,name):
    if columns-set(f):raise ValueError(name+' schema missing '+str(sorted(columns-set(f))))

def download(url,path):
    """Save original bytes and record retrieval metadata; source errors stay explicit."""
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    request=urllib.request.Request(url,headers={'User-Agent':'NFL-V3-prospective-research/1.0'})
    with urllib.request.urlopen(request,timeout=90) as response:
        raw=response.read();last=response.headers.get('Last-Modified');etag=response.headers.get('ETag')
    path.write_bytes(raw)
    return dict(url=url,captured_at_utc=datetime.now(timezone.utc).isoformat(),last_modified_utc=parsedate_to_datetime(last).astimezone(timezone.utc).isoformat() if last else None,etag=etag,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def recent_source(meta,cutoff,hours=48):
    try:
        t=utc(meta['last_modified_utc']);captured=utc(meta['captured_at_utc'])
        return t<=captured<=cutoff and cutoff-t<=pd.Timedelta(hours=hours)
    except (TypeError,ValueError,KeyError):return False

def latest_depth(frame,cutoff):
    f=canon(frame.rename(columns={'player_gsis_id':'gsis_id','player_espn_id':'espn_id'}))
    require(f,DEPTH_REQUIRED,'Depth charts')
    f['_dt']=pd.to_datetime(f.dt,utc=True,errors='coerce')
    f=f[f._dt.notna()&f._dt.le(cutoff)]
    if f.empty:return f.drop(columns=['_dt'])
    newest=f.groupby('team')._dt.transform('max')
    return f[f._dt.eq(newest)].drop(columns=['_dt']).copy()

def snap_history(snaps,players,games,cutoff):
    s=canon(snaps);require(s,SNAP_REQUIRED,'Snap counts');require(players,{'gsis_id','pfr_id'},'Players')
    ids=players[['pfr_id','gsis_id']].drop_duplicates()
    ids=ids[ids.pfr_id.ne('')&ids.gsis_id.ne('')]
    # Conflicting IDs cannot be silently matched by name.
    bad=ids.groupby('pfr_id').gsis_id.nunique();ids=ids[~ids.pfr_id.isin(bad[bad.gt(1)].index)]
    s=s.merge(ids,left_on='pfr_player_id',right_on='pfr_id',how='left',validate='many_to_one')
    s=s.merge(games[['game_id','kickoff_utc']],on='game_id',how='left',validate='many_to_one')
    s=s[s.kickoff_utc.notna()&(s.kickoff_utc+pd.Timedelta(hours=12)<=cutoff)&s.gsis_id.notna()]
    for c in ['offense_pct','defense_pct','st_pct']:
        s[c]=pd.to_numeric(s[c],errors='coerce')
        s.loc[~s[c].between(0,1),c]=float('nan')
    # Duplicate player/game stats are ambiguous and excluded rather than summed.
    s=s[~s.duplicated(['game_id','team','gsis_id'],keep=False)]
    return s.sort_values('kickoff_utc').groupby(['team','gsis_id'],group_keys=False).tail(3)

def position_group(position):
    p=str(position).upper()
    p={'LT':'T','RT':'T','LG':'G','RG':'G','LDE':'DE','RDE':'DE','LDT':'DT','RDT':'DT','WLB':'LB','MLB':'LB','SLB':'LB','LCB':'CB','RCB':'CB','NB':'DB'}.get(p,p)
    return GROUPS.get(p,'UNKNOWN')

def derive(games,targets,depth,injuries,snaps,players,cutoff,injury_meta):
    cutoff=utc(cutoff)
    d=latest_depth(depth,cutoff);inj=canon(injuries);require(inj,INJ_REQUIRED,'Injuries')
    for c in ['season','week']:inj[c]=pd.to_numeric(inj[c],errors='coerce')
    if 'season_type' not in inj and 'game_type' not in inj:raise ValueError('Injuries need REG/POST season_type or game_type')
    typecol='season_type' if 'season_type' in inj else 'game_type'
    inj[typecol]=inj[typecol].astype(str).str.upper().replace({'REGULAR':'REG','POSTSEASON':'POST'})
    history=snap_history(snaps,players,games,cutoff)
    current=recent_source(injury_meta,cutoff)
    teamrows=[];playerrows=[];qrows=[]
    for g in targets.itertuples():
        if g.kickoff_utc<=cutoff:continue
        for team in [g.home_team,g.away_team]:
            r=dict(game_id=g.game_id,team=team,feature_cutoff_utc=cutoff.isoformat(),injury_feed_status='missing',qb_candidate_status='missing',qb_candidate_id='',qb_candidate_name='',qb_candidate_rank=None,qb_injury_status='unknown',depth_asof_utc='',injury_players_reported=0,known_out_players=0,unresolved_designations=0,known_out_players_without_snap_history=0)
            ti=inj[inj.season.eq(int(g.season))&inj.week.eq(int(g.week))&inj.team.eq(team)&inj[typecol].eq(str(g.game_type).upper())].copy()
            # Without reliable individual modification timestamps, conflicting
            # duplicate player reports remain unresolved, never last-row-wins.
            ambiguous=set(ti.loc[ti.duplicated('gsis_id',keep=False),'gsis_id'])
            if current and not ti.empty:
                r['injury_feed_status']='observed_partial'
            usable=current and not ti.empty
            r['injury_players_reported']=len(ti) if usable else 0
            out_weights={group:0.0 for group in sorted(set(GROUPS.values()))}
            for item in ti.itertuples():
                if not usable:continue
                designation=str(item.report_status).strip()
                unknown_id=not str(item.gsis_id).strip()
                known_out=designation.lower()=='out' and item.gsis_id not in ambiguous and not unknown_id
                group=position_group(item.position)
                column='offense_pct' if group in ['QB','OL','REC','RB'] else 'st_pct' if group=='ST' else 'defense_pct'
                hp=history[history.team.eq(team)&history.gsis_id.eq(item.gsis_id)] if not unknown_id else history.iloc[0:0]
                share=float(hp[column].mean()) if len(hp) and hp[column].notna().any() else None
                unresolved=designation.lower() in ['questionable','doubtful'] or item.gsis_id in ambiguous or unknown_id or designation.lower() not in ['out','']
                r['known_out_players']+=int(known_out)
                r['unresolved_designations']+=int(unresolved)
                r['known_out_players_without_snap_history']+=int(known_out and share is None)
                if known_out and share is not None and group in out_weights:out_weights[group]+=share
                playerrows.append(dict(game_id=g.game_id,team=team,player_id=item.gsis_id,player_name=item.full_name,position=item.position,position_group=group,report_status=designation or 'no_game_designation_supplied',practice_status=item.practice_status,known_out=known_out,status_ambiguous=item.gsis_id in ambiguous,recent_snap_share_proxy=share,prior_games_used=int(hp[column].notna().sum()),source_observed_at_utc=injury_meta.get('captured_at_utc'),availability_probability=None))
            for group,value in out_weights.items():
                # This is a partial sum for observed Out players with known snaps.
                # It is not a complete team injury burden or a learned point value.
                r['observed_out_snap_proxy_'+group]=value if usable else None
            td=d[d.team.eq(team)].copy()
            if not td.empty:
                stamp=utc(td.dt.iloc[0]);r['depth_asof_utc']=stamp.isoformat()
                if cutoff-stamp>pd.Timedelta(hours=48):r['qb_candidate_status']='stale_depth_chart'
                else:
                    tq=td[td.pos_abb.eq('QB')].copy();tq['rank']=pd.to_numeric(tq.pos_rank,errors='coerce')
                    tq=tq[tq.gsis_id.ne('')&tq['rank'].ge(1)].sort_values('rank').drop_duplicates('gsis_id')
                    excluded=set(ti.loc[ti.report_status.str.lower().eq('out')&~ti.gsis_id.isin(ambiguous),'gsis_id']) if usable else set()
                    tq=tq[~tq.gsis_id.isin(excluded)]
                    for q in tq.itertuples():qrows.append(dict(game_id=g.game_id,team=team,qb_id=q.gsis_id,qb_name=q.player_name,depth_rank=int(q.rank),depth_asof_utc=stamp.isoformat(),status='DEPTH_CHART_CANDIDATE_NOT_CONFIRMED',start_probability=None))
                    best=tq[tq['rank'].eq(tq['rank'].min())] if len(tq) else tq
                    if len(best)==1:
                        b=best.iloc[0];qi=ti[ti.gsis_id.eq(b.gsis_id)] if usable else ti.iloc[0:0]
                        status='unknown' if qi.empty else 'ambiguous' if len(qi)>1 else str(qi.report_status.iloc[0]) or 'no_game_designation_supplied'
                        r.update(qb_candidate_status='depth_chart_only',qb_candidate_id=b.gsis_id,qb_candidate_name=b.player_name,qb_candidate_rank=int(b['rank']),qb_injury_status=status)
                        if status.lower() in ['questionable','doubtful','ambiguous']:r['qb_candidate_status']='uncertain_injury'
                    elif len(best)>1:r['qb_candidate_status']='ambiguous_depth_chart'
            teamrows.append(r)
    teamfeatures=pd.DataFrame(teamrows)
    gamerows=[]
    for g in targets.itertuples():
        if g.kickoff_utc<=cutoff:continue
        group=teamfeatures[teamfeatures.game_id.eq(g.game_id)].set_index('team')
        row=dict(game_id=g.game_id)
        for side,team in [('home',g.home_team),('away',g.away_team)]:
            for k,v in group.loc[team].items():row['auto_'+side+'_'+k]=v
        for key in ['observed_out_snap_proxy_'+p for p in sorted(set(GROUPS.values()))]:
            h,a=group.loc[g.home_team,key],group.loc[g.away_team,key]
            row['auto_'+key+'_diff']=h-a if pd.notna(h) and pd.notna(a) else None
        gamerows.append(row)
    return teamfeatures,pd.DataFrame(playerrows),pd.DataFrame(qrows),pd.DataFrame(gamerows,columns=None if gamerows else ['game_id'])

def fetch_sources(season,out,local=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    config={'depth':('depth_charts',f'depth_charts_{season}.csv'),'injuries':('injuries',f'injuries_{season}.csv'),'snaps':('snap_counts',f'snap_counts_{season}.csv'),'players':('players','players.csv')}
    frames={};metadata={}
    for key,(tag,name) in config.items():
        path=out/(key+'.csv');url=ROOT+tag+'/'+name
        if local:
            source=Path(local)/('source_'+key+'.csv')
            if not source.exists():raise ValueError('Missing local source '+str(source))
            raw=source.read_bytes();path.write_bytes(raw)
            manifest=Path(local)/'source_metadata.json'
            known=json.loads(manifest.read_text()).get(key,{}) if manifest.exists() else {}
            metadata[key]=dict(known,url=url,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),local_replay=True)
        else:metadata[key]=download(url,path)
        frames[key]=read_csv(path)
        (out/'source_metadata.json').write_text(json.dumps(metadata,indent=2))
        # Compress each source immediately so a later feed failure still leaves
        # an auditable, reasonably sized archive for sources already retrieved.
        with gzip.open(path.with_suffix('.csv.gz'),'wb') as dest:
            dest.write(path.read_bytes())
        path.unlink()
    return frames,metadata

def run(args):
    base=Path(args.availability);out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
    games=schedule(base/'schedule.csv')
    prior=read_csv(base/'game_features.csv')
    now=utc(datetime.now(timezone.utc).isoformat())
    selected=games[games.game_id.isin(prior.game_id)&games.kickoff_utc.gt(now)]
    seasons=selected.season.unique()
    if len(seasons)>1:raise ValueError('Automatic reports require one NFL season per capture')
    if len(seasons)==0:
        (out/'source_manifest.json').write_text(json.dumps(dict(status='NO_UPCOMING_MATCHED_GAMES',note='No source requests made.'),indent=2));return
    sources,meta=fetch_sources(int(seasons[0]),out/'sources',args.sources)
    cutoff=utc(datetime.now(timezone.utc).isoformat())
    teams,players,qbs,gfeatures=derive(games,selected,sources['depth'],sources['injuries'],sources['snaps'],sources['players'],cutoff,meta['injuries'])
    # Keep the exact CSV bytes for small feeds. The season-long depth file can
    # exceed GitHub's limit; archive a compressed original plus the selected view.
    for path in (out/'sources').glob('*.csv'):
        raw=path.read_bytes()
        with gzip.open(path.with_suffix('.csv.gz'),'wb') as dest:dest.write(raw)
        path.unlink()
    latest_depth(sources['depth'],cutoff).to_csv(out/'depth_snapshot.csv',index=False)
    for name,frame in [('team_features',teams),('injury_records',players),('qb_candidates',qbs),('auto_game_features',gfeatures)]:frame.to_csv(out/(name+'.csv'),index=False)
    enriched=prior.merge(gfeatures,on='game_id',how='left',validate='one_to_one')
    if 'feature_cutoff_utc' in enriched:
        enriched=enriched.rename(columns={'feature_cutoff_utc':'base_feature_cutoff_utc'})
    enriched['feature_cutoff_utc']=cutoff.isoformat()
    enriched.to_csv(out/'game_features_enriched.csv',index=False)
    summary=dict(status='AUTOMATIC_SOURCE_REPORTS_COLLECTED',feature_cutoff_utc=cutoff.isoformat(),games=len(gfeatures),team_rows=len(teams),teams_with_qb_candidate=int(teams.qb_candidate_id.ne('').sum()) if len(teams) else 0,teams_with_current_week_injury_rows=int(teams.injury_feed_status.eq('observed_partial').sum()) if len(teams) else 0,injury_records=len(players),confirmed_qb_probabilities_generated=0,sources=meta,
        limits=['Depth-chart candidates are not confirmed game starters; no starting probabilities are invented.','Questionable/doubtful are categorical, not mapped to arbitrary play probabilities.','Injury rows are partial and do not establish a healthy roster or report completeness.','Snap shares are recent-use proxies, not estimated healthy usage or replacement quality.','IR/reserve list coverage is not supplied by these weekly injury reports.','No historical as-of reconstruction; report observations begin at capture time.','No fitted injury/QB effects or new betting predictions are produced.'])
    (out/'source_manifest.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ['sources','limits']}))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--availability',required=True);ap.add_argument('--out',required=True);ap.add_argument('--sources',help='Local source directory for replay; requires source_metadata.json for freshness claims')
    run(ap.parse_args())
