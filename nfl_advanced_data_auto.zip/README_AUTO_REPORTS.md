# Automatic source reports for NFL V3

This adds free nflverse depth charts, weekly injury reports, player ID mapping and earlier-game snap counts to your working odds archive. No second API key is needed. Collection occurs when you manually run capture; there is no recurring schedule.

## Install

Upload `nfl_advanced_data_auto.zip` STILL ZIPPED to your repository's main folder. Edit the existing `.github/workflows/nfl-advanced-data.yml` with the full YAML provided in chat. The new workflow uses this distinct ZIP filename and its paired checksum, so the previous tools ZIP can remain. Commit to main, start a NEW test run on main, then start a NEW capture run. Re-running an old job can reuse old code.

ODDS_API_KEY remains the only secret. Tests use no live odds. Capture makes one odds request and retrieves public nflverse files, including the roughly 75 MB depth-chart history. The raw files are compressed before archiving. Downloads can take several minutes; repository data history grows with each run. This package does not configure a paid feed or purchase data.

## New output

The downloadable artifact now includes `auto_reports/`:

- `source_manifest.json`: retrieval timestamps, source URLs, HTTP last-modified timestamps, raw-byte checksums, summary counts and limitations.
- `sources/`: compressed exact source files and incremental source metadata; retained on the data branch even if a later feed fails.
- `depth_snapshot.csv`: latest non-future depth snapshot for each team.
- `qb_candidates.csv`: ranked depth-chart QB candidates. Starting probabilities remain blank.
- `injury_records.csv`: raw official-report and practice designations, GSIS player IDs, and earlier-game snap share proxies where IDs resolve uniquely.
- `team_features.csv`: source coverage, likely QB candidate, uncertainty flags and position-group exposure from observed Out players.
- `auto_game_features.csv`: automatic features with home/away columns and differences.
- `game_features_enriched.csv`: the existing feature table joined to the automatic fields. Its top-level feature cutoff advances to automatic collection time; the earlier cutoff is preserved as base_feature_cutoff_utc.

These files are also committed under `data/auto_reports/<run-id>-<attempt>/` on the existing nfl-data-archive branch. The original `availability/manifest.json` still describes the MANUAL probability/coverage layer. Its ready_teams count can remain zero while automatic reports are present. Use auto_reports/source_manifest.json for automatic-source coverage.

## What is and isn't inferred

A depth-chart leader is a candidate, not a confirmed game starter. A primary QB explicitly listed Out in a current same-week report is skipped; the next ranked candidate remains unconfirmed. Questionable/Doubtful designations flag uncertainty. Multiple equal-ranked leaders or conflicting reports remain ambiguous. Candidate data is not written into the manual probability ledger as a fabricated 100% probability.

Injury rows must match the game's season, REG/POST type, week and team, and the source file must have a verifiable last-modified timestamp no more than 48 hours old. Missing future-week reports remain missing. An absent player designation is not interpreted as a healthy roster. Weekly injury reports do not supply complete IR/reserve coverage.

Recent snap shares use at most the last 3 earlier completed games with available, uniquely mapped player records, using a conservative 12-hour completion buffer. No fuzzy name matches are made. These are usage proxies, not healthy snap estimates or replacement-quality ratings. Invalid percentages, missing IDs and ambiguous mappings remain missing.

`observed_out_snap_proxy_<position group>` is the sum of recent snap-share proxies for observed players explicitly listed Out with matched history. It is a PARTIAL observed exposure, not a complete team injury burden or expected points adjustment. Known-out players without history are counted separately. No arbitrary probabilities are assigned to Questionable or Doubtful.

Prospective report collection begins when the source is retrieved. File-level freshness is not an individual report publication guarantee. Neither this collector nor the underlying providers establish a retrospective as-of injury archive from current data. Preserved snapshots enable future as-of work.

## Model status

The locked V3 EPA model and prior workflows are unchanged. This release connects automatic report sources and exports features; it does not retrain V3, produce improved cover probabilities, or establish a win-rate improvement. Confirmed starter announcements, calibrated availability probabilities, IR roster coverage, replacement quality and a chronological model comparison remain future work.

## Validation

See validation.txt. example_output contains the actual integration outputs and compressed source observations; these are dated examples, not current predictions. Tests cover source schemas, Rams aliases, stale/future sources, same-week/type filtering, ambiguous IDs/reports/depth ranks, unavailable primary QBs, missing designations, snap-history leakage, source compression, and the existing archive pipeline. A live public-source integration run against the user's 24-game capture produced 48 depth-chart candidates and 276 injury rows with 24 same-week team/game report sets. Some remaining team/game entries refer to next week and have no current reports. This run did not use an odds API key, spend odds quota or run the updated workflow on GitHub. No betting performance was tested.

Sources and attribution: nflverse/nflreadr contributors; depth charts sourced upstream from ESPN and snap counts from Pro Football Reference via nflverse.
- https://nflreadr.nflverse.com/articles/dictionary_depth_charts.html
- https://nflreadr.nflverse.com/articles/dictionary_injuries.html
- https://nflreadr.nflverse.com/articles/dictionary_snap_counts.html
- https://github.com/nflverse/nflverse-data
