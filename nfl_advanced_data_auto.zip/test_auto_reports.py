import unittest
from pathlib import Path
import tempfile
import pandas as pd
from auto_reports import derive,latest_depth,utc,recent_source,position_group,snap_history,fetch_sources

class AutoReportTests(unittest.TestCase):
    def setUp(self):
        self.cutoff=utc('2026-11-13T09:00:00Z')
        self.games=pd.DataFrame([
            dict(game_id='old',home_team='SF',away_team='SEA',season=2026,week=9,game_type='REG',kickoff_utc=utc('2026-11-08T21:00:00Z')),
            dict(game_id='next',home_team='SF',away_team='SEA',season=2026,week=10,game_type='REG',kickoff_utc=utc('2026-11-15T21:00:00Z'))])
        self.targets=self.games.iloc[[1]]
        self.depth=pd.DataFrame([dict(dt='2026-11-13T07:00:00Z',team='SF',gsis_id='qb1',player_name='Starter',pos_abb='QB',pos_rank='1'),dict(dt='2026-11-13T07:00:00Z',team='SF',gsis_id='qb2',player_name='Backup',pos_abb='QB',pos_rank='2')])
        self.inj=pd.DataFrame([dict(season='2026',week='10',season_type='REG',team='SF',gsis_id='tackle',position='T',full_name='Tackle',report_status='Out',practice_status='Did Not Participate')])
        self.snaps=pd.DataFrame([dict(game_id='old',pfr_player_id='pfr_tackle',team='SF',offense_pct='.8',defense_pct='0',st_pct='0')])
        self.players=pd.DataFrame([dict(gsis_id='tackle',pfr_id='pfr_tackle')])
        self.meta=dict(last_modified_utc='2026-11-13T07:00:00Z',captured_at_utc='2026-11-13T08:00:00Z')
    def derive(self):return derive(self.games,self.targets,self.depth,self.inj,self.snaps,self.players,self.cutoff,self.meta)
    def test_live_shape_proxies_and_unknown_team(self):
        t,p,q,g=self.derive();self.assertEqual(len(t),2)
        sf=t[t.team.eq('SF')].iloc[0];sea=t[t.team.eq('SEA')].iloc[0]
        self.assertEqual(sf.qb_candidate_id,'qb1');self.assertEqual(sf.qb_candidate_status,'depth_chart_only')
        self.assertAlmostEqual(sf.observed_out_snap_proxy_OL,.8)
        self.assertTrue(pd.isna(sea.observed_out_snap_proxy_OL))
        self.assertTrue(p.availability_probability.isna().all());self.assertTrue(q.start_probability.isna().all())
        self.assertEqual(g.iloc[0].auto_home_qb_candidate_id,'qb1')
    def test_questionable_not_given_probability(self):
        self.inj.loc[0,'report_status']='Questionable';self.inj.loc[0,'gsis_id']='qb1'
        t,p,_,_=self.derive();self.assertEqual(t.iloc[0].qb_candidate_status,'uncertain_injury')
        self.assertTrue(p.availability_probability.isna().all());self.assertEqual(t.iloc[0].known_out_players,0)
    def test_out_qb_skipped_without_claiming_confirmation(self):
        self.inj.loc[0,'gsis_id']='qb1';self.inj.loc[0,'position']='QB'
        t,_,_,_=self.derive();self.assertEqual(t.iloc[0].qb_candidate_id,'qb2')
        self.assertEqual(t.iloc[0].qb_candidate_status,'depth_chart_only')
    def test_week_mismatch_not_healthy(self):
        self.inj['week']='9';t,p,_,_=self.derive()
        self.assertTrue(t.injury_feed_status.eq('missing').all());self.assertTrue(p.empty)
        self.assertTrue(t.observed_out_snap_proxy_OL.isna().all())
    def test_stale_injury_feed_withheld(self):
        self.meta['last_modified_utc']='2026-11-01T07:00:00Z';t,p,_,_=self.derive()
        self.assertTrue(t.injury_feed_status.eq('missing').all());self.assertTrue(p.empty)
    def test_missing_last_modified_withheld(self):
        del self.meta['last_modified_utc'];self.assertFalse(recent_source(self.meta,self.cutoff))
    def test_future_source_not_used(self):
        self.meta['captured_at_utc']='2026-11-13T10:00:00Z';t,p,_,_=self.derive()
        self.assertTrue(p.empty)
    def test_future_depth_snapshot_ignored(self):
        future=self.depth.copy();future['dt']='2026-11-14T07:00:00Z';future['gsis_id']='wrong'
        self.depth=pd.concat([future,self.depth]);t,_,_,_=self.derive()
        self.assertEqual(t.iloc[0].qb_candidate_id,'qb1')
    def test_stale_depth_blocked(self):
        self.depth['dt']='2026-11-01T07:00:00Z';t,_,q,_=self.derive()
        self.assertEqual(t.iloc[0].qb_candidate_status,'stale_depth_chart');self.assertTrue(q.empty)
    def test_ambiguous_depth_not_guessed(self):
        self.depth.loc[1,'pos_rank']='1';t,_,_,_=self.derive()
        self.assertEqual(t.iloc[0].qb_candidate_status,'ambiguous_depth_chart');self.assertEqual(t.iloc[0].qb_candidate_id,'')
    def test_future_game_snaps_do_not_leak(self):
        self.snaps.loc[0,'game_id']='next';t,p,_,_=self.derive()
        self.assertTrue(pd.isna(p.iloc[0].recent_snap_share_proxy));self.assertEqual(t.iloc[0].known_out_players_without_snap_history,1)
    def test_id_conflict_not_name_matched(self):
        self.players=pd.concat([self.players,pd.DataFrame([dict(gsis_id='different',pfr_id='pfr_tackle')])])
        _,p,_,_=self.derive();self.assertTrue(pd.isna(p.iloc[0].recent_snap_share_proxy))
    def test_duplicate_reports_not_last_row_wins(self):
        self.inj=pd.concat([self.inj,self.inj]);t,p,_,_=self.derive()
        self.assertEqual(t.iloc[0].known_out_players,0);self.assertTrue(p.status_ambiguous.all())
    def test_season_and_type_mismatch(self):
        self.inj['season_type']='POST';t,p,_,_=self.derive();self.assertTrue(p.empty)
        self.inj['season_type']='REG';self.inj['season']='2025';t,p,_,_=self.derive();self.assertTrue(p.empty)
    def test_rams_alias_and_supported_new_id_columns(self):
        self.depth['team']='LA';self.depth=self.depth.rename(columns={'gsis_id':'player_gsis_id'})
        d=latest_depth(self.depth,self.cutoff);self.assertTrue(d.team.eq('LAR').all());self.assertIn('gsis_id',d)
    def test_snap_percent_invalid_is_missing(self):
        self.snaps['offense_pct']='80';_,p,_,_=self.derive();self.assertTrue(pd.isna(p.iloc[0].recent_snap_share_proxy))
    def test_unsupported_source_schema_fails(self):
        self.depth=self.depth.drop(columns=['pos_abb'])
        with self.assertRaises(ValueError):self.derive()
    def test_position_alias(self):
        self.assertEqual(position_group('LT'),'OL');self.assertEqual(position_group('RCB'),'DB');self.assertEqual(position_group('unknown'),'UNKNOWN')
    def test_source_replay_keeps_compressed_originals(self):
        import json,gzip
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);local=root/'input';local.mkdir()
            for key,frame in [('depth',self.depth),('injuries',self.inj),('snaps',self.snaps),('players',self.players)]:
                frame.to_csv(local/('source_'+key+'.csv'),index=False)
            (local/'source_metadata.json').write_text(json.dumps({'injuries':self.meta}))
            frames,meta=fetch_sources(2026,root/'output',str(local))
            self.assertEqual(len(frames['depth']),2)
            self.assertTrue(meta['injuries']['local_replay'])
            self.assertTrue(recent_source(meta['injuries'],self.cutoff))
            self.assertTrue((root/'output/source_metadata.json').exists())
            self.assertFalse((root/'output/depth.csv').exists())
            with gzip.open(root/'output/depth.csv.gz','rb') as source:self.assertEqual(source.read(),(local/'source_depth.csv').read_bytes())

if __name__=='__main__':unittest.main()
