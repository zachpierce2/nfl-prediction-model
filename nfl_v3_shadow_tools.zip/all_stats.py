"""Additional pregame rates; trainable candidate alongside locked V3.

Rates pool counts over the previous eight completed games, with .85 decay.
No same-day or current-game observations enter a feature row.
"""
import argparse
import hashlib
import json
import urllib.request
from collections import defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
from model_v3_epa import canonical, PBP_URL

VERSION = 'ALL_STATS_V1'
PAIRS = {'explosive': ('explosive_plays', 'scrimmage_plays'),
         'sack': ('sacks', 'dropbacks'),
         'third_down': ('third_conversions', 'third_attempts'),
         'red_zone_td': ('red_zone_tds', 'red_zone_trips')}
COUNTS = list(dict.fromkeys(c for pair in PAIRS.values() for c in pair))
RATE_COLUMNS = [side + metric + '_rate' for side in ['off_', 'def_'] for metric in PAIRS]
EXTRA = [c + '_diff' for c in RATE_COLUMNS] + [side + c + '_missing' for side in ['home_', 'away_'] for c in RATE_COLUMNS]
PBP_COLUMNS = ['game_id','posteam','defteam','play_type','qb_dropback','qb_kneel','qb_spike',
               'yards_gained','sack','third_down_converted','third_down_failed','down',
               'yardline_100','fixed_drive','pass_touchdown','rush_touchdown','no_play']

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def aggregate(frame):
    if set(PBP_COLUMNS) - set(frame):
        raise ValueError('Missing extended PBP columns: ' + str(sorted(set(PBP_COLUMNS)-set(frame))))
    p = frame.copy()
    p = p[p.posteam.notna() & p.defteam.notna()].copy()
    for c in PBP_COLUMNS[4:]:
        p[c] = pd.to_numeric(p[c], errors='coerce')
    p['posteam'] = p.posteam.map(canonical)
    p['defteam'] = p.defteam.map(canonical)
    valid = p.play_type.isin(['pass','run']) & p.no_play.fillna(0).ne(1) & p.qb_kneel.fillna(0).ne(1) & p.qb_spike.fillna(0).ne(1)
    q = p[valid].copy()
    # A single consistent, documented explosive definition: 20+ yards gained.
    q['explosive_plays'] = q.yards_gained.ge(20).astype(int)
    q['scrimmage_plays'] = 1
    q['dropbacks'] = q.qb_dropback.eq(1).astype(int)
    q['sacks'] = (q.sack.eq(1) & q.qb_dropback.eq(1)).astype(int)
    # Use recorded conversion/failure flags; unclassified downs are not attempts.
    q['third_attempts'] = (q.down.eq(3) & (q.third_down_converted.eq(1) | q.third_down_failed.eq(1))).astype(int)
    q['third_conversions'] = (q.third_attempts.eq(1) & q.third_down_converted.eq(1)).astype(int)
    keys = ['game_id','posteam','defteam']
    t = q.groupby(keys, as_index=False)[COUNTS[:6]].sum()
    # One trip per possession with a valid pre-snap play at/beyond the 20.
    # Field goals, kneels and spikes can establish a trip; nullified plays cannot.
    d = p[p.fixed_drive.notna() & p.no_play.fillna(0).ne(1) & p.play_type.isin(['pass','run','field_goal','qb_kneel','qb_spike'])].copy()
    d['entered'] = d.yardline_100.between(0,20).astype(int)
    d['offensive_td'] = (d.pass_touchdown.eq(1) | d.rush_touchdown.eq(1)).astype(int)
    drives = d.groupby(keys+['fixed_drive'], as_index=False)[['entered','offensive_td']].max()
    drives['red_zone_trips'] = drives.entered
    drives['red_zone_tds'] = drives.entered * drives.offensive_td
    rz = drives.groupby(keys,as_index=False)[['red_zone_tds','red_zone_trips']].sum()
    return t.merge(rz,on=keys,how='left',validate='one_to_one').fillna({'red_zone_tds':0,'red_zone_trips':0})

def features(games, counts, cutoff):
    if counts.duplicated(['game_id','posteam']).any():
        raise ValueError('Duplicate extended team/game statistics')
    g = games.copy()
    g['gameday'] = pd.to_datetime(g.gameday,utc=True)
    g['kickoff_utc'] = pd.to_datetime(g.kickoff_utc,utc=True)
    cutoff = pd.Timestamp(cutoff)
    lookup = {(r.game_id,r.posteam):r._asdict() for r in counts.itertuples(index=False)}
    histories = defaultdict(list)
    rows = []
    def profile(team):
        hist = histories[team][-8:]
        result = {}
        for side in ['off_','def_']:
            for metric,(num,den) in PAIRS.items():
                weights = .85 ** np.arange(len(hist)-1,-1,-1)
                n = sum(w*r[side+num] for w,r in zip(weights,hist))
                d = sum(w*r[side+den] for w,r in zip(weights,hist))
                result[side+metric+'_rate'] = n/d if d else np.nan
        return result
    for day,group in g.sort_values(['gameday','game_id']).groupby('gameday'):
        for r in group.itertuples():
            h,a = profile(canonical(r.home_team)),profile(canonical(r.away_team))
            row = {'game_id':r.game_id}
            for c in RATE_COLUMNS:
                row[c+'_diff'] = h[c]-a[c]
                for side,p in [('home',h),('away',a)]:
                    row[side+'_'+c] = p[c]
                    row[side+'_'+c+'_missing'] = float(not np.isfinite(p[c]))
            rows.append(row)
        for r in group.itertuples():
            if pd.isna(r.home_score) or pd.isna(r.away_score) or r.kickoff_utc+pd.Timedelta(hours=12)>cutoff:
                continue
            h,a = canonical(r.home_team),canonical(r.away_team)
            own,other = lookup.get((r.game_id,h)),lookup.get((r.game_id,a))
            if own is None or other is None:
                raise ValueError('Missing extended PBP coverage for completed game '+r.game_id)
            for team,o,d in [(h,own,other),(a,other,own)]:
                histories[team].append({**{'off_'+c:o[c] for c in COUNTS},**{'def_'+c:d[c] for c in COUNTS}})
    return pd.DataFrame(rows)

def prepare(cache):
    cache = Path(cache); cache.mkdir(parents=True,exist_ok=True)
    for season in range(2017,2026):
        dest = cache/f'counts_{season}.csv'
        meta = cache/f'counts_{season}.json'
        if dest.exists() and meta.exists() and json.loads(meta.read_text()).get('version')==VERSION and json.loads(meta.read_text()).get('aggregate_sha256')==digest(dest):
            continue
        raw = cache/f'play_by_play_{season}.parquet'
        print('Downloading extended statistics:',season,flush=True)
        with urllib.request.urlopen(PBP_URL.format(season=season),timeout=180) as response:
            with raw.open('wb') as output:
                while block := response.read(1024*1024): output.write(block)
        counts = aggregate(pd.read_parquet(raw,columns=PBP_COLUMNS))
        counts.to_csv(dest,index=False)
        meta.write_text(json.dumps({'version':VERSION,'season':season,'source_url':PBP_URL.format(season=season),'raw_sha256':digest(raw),'aggregate_sha256':digest(dest)},indent=2))
        raw.unlink()

def add_candidate(games, core, selected, live_counts, cutoff, cache, out, auto, evidence, qbs):
    from shadow_compare import COLUMNS, regressor
    from threadpoolctl import threadpool_limits
    from verified_qb import scenarios
    out=Path(out); cache=Path(cache)
    frames=[];sources=[]
    for season in range(2017,2026):
        path=cache/f'counts_{season}.csv';meta=json.loads((cache/f'counts_{season}.json').read_text())
        if digest(path)!=meta['aggregate_sha256']:raise ValueError('Extended cache checksum mismatch')
        frames.append(pd.read_csv(path));sources.append(meta)
    counts=pd.concat(frames+[live_counts],ignore_index=True)
    extra=features(games[games.season.ge(2017)],counts,cutoff)
    data=core.merge(extra,on='game_id',validate='one_to_one')
    train=data[data.season.between(2017,2025)&data.actual_margin.notna()]
    cols=COLUMNS+EXTRA
    live=data[data.game_id.isin(selected.game_id)].copy()
    live=live.merge(selected[['game_id','baseline_predicted_margin','neutral_predicted_margin']],on='game_id',validate='one_to_one')
    with threadpool_limits(limits=1):
        model=regressor().fit(train[cols],train.actual_margin)
        live['all_stats_predicted_margin']=model.predict(live[cols]) if len(live) else []
        # Actual verified starter overrides remain a separate source-attributed output.
        scenario_input=live.copy()
        scenario_input['baseline_predicted_margin']=live.all_stats_predicted_margin
        starter=scenarios(scenario_input,auto,evidence,qbs,games,cutoff,model,cols)
        backtests=[];scores=[]
        for year in range(2020,2026):
            tr=train[train.season.lt(year)];te=train[train.season.eq(year)]
            if tr.empty or te.empty:continue
            for label,inputs in [('neutral_core',COLUMNS),('all_stats',cols)]:
                m=regressor().fit(tr[inputs],tr.actual_margin);pred=m.predict(te[inputs])
                p=te[['game_id','season','home_team','away_team','actual_margin']].copy()
                p['model']=label;p['predicted_margin']=pred;backtests.append(p)
                scores.append({'season':year,'model':label,'games':len(te),'mae':float(np.mean(abs(pred-te.actual_margin)))})
    live['forecast_cutoff_utc']=cutoff.isoformat()
    live['prediction_created_at_utc']=pd.Timestamp.now(tz='UTC').isoformat()
    live['all_stats_status']='RESEARCH_CANDIDATE_UNVALIDATED'
    live['home_all_stats_spread']=-live.all_stats_predicted_margin
    live.to_csv(out/'all_stats_forecasts.csv',index=False)
    audit_path=out/'all_game_forecasts.csv'
    if audit_path.exists():
        audit=pd.read_csv(audit_path).merge(live[['game_id','all_stats_predicted_margin','home_all_stats_spread','all_stats_status']],on='game_id',how='left',validate='one_to_one')
        audit.to_csv(audit_path,index=False)
    starter.to_csv(out/'all_stats_starter_scenarios.csv',index=False)
    pd.concat(backtests,ignore_index=True).to_csv(out/'all_stats_backtest_predictions.csv',index=False)
    pd.DataFrame(scores).to_csv(out/'all_stats_backtest_by_season.csv',index=False)
    summary={'version':VERSION,'status':'RESEARCH_CANDIDATE_UNVALIDATED','forecast_games':len(live),'feature_columns':cols,'new_features':EXTRA,'historical_sources':sources,
             'method':'Same neutral-site core and estimator; additional rate inputs retrained on 2017-2025. Walk-forward comparison trains prior seasons only, 2020-2025 exploratory.',
             'definitions':{'explosive':'20+ yards gained per valid pass/run play, including QB scrambles; excludes kneels, spikes and nullified plays','sack':'sacks / QB dropbacks, including scrambles','third_down':'recorded third-down conversions / recorded converted-or-failed third downs; valid scrimmage plays only','red_zone_td':'offensive-TD possessions / possessions with a valid pre-snap play at or inside the opponent 20; one trip per possession'},
             'history':'Prior 8 completed games; .85 decay applied to numerator and denominator counts. Zero opportunities remain missing, with explicit missing indicators.',
             'limits':['Not a demonstrated win-rate improvement.','Historical PBP is revised data, not point-in-time archived observations.','Definitions may differ from the screenshot provider.','Original locked V3 and existing QB/neutral forecasts remain in their original files.','Starter scenarios require evidence; injury adjustments are not promoted by this change.','No automatic starter-news collector was installed.']}
    (out/'all_stats_summary.json').write_text(json.dumps(summary,indent=2))
    return summary

def evaluate_archive(archive, games, cutoff, out):
    """Grade the first pregame snapshot per game on identical completed games."""
    out=Path(out); frames=[]
    for p in sorted((Path(archive)/'data/shadow_predictions').glob('*/all_stats_forecasts.csv')):
        manifest=json.loads((p.parent/'manifest.json').read_text())
        if manifest.get('all_stats_candidate',{}).get('version')!=VERSION:continue
        if manifest.get('files',{}).get(p.name)!=digest(p):raise ValueError('All-stats ledger checksum mismatch')
        f=pd.read_csv(p)
        if len(f):frames.append(f)
    columns=['game_id','home_team','away_team','kickoff_utc','prediction_created_at_utc','actual_margin','baseline_predicted_margin','neutral_predicted_margin','all_stats_predicted_margin']
    rows=[]
    if frames:
        f=pd.concat(frames,ignore_index=True)
        for c in ['kickoff_utc','prediction_created_at_utc','forecast_cutoff_utc']:f[c]=pd.to_datetime(f[c],utc=True,errors='raise')
        f=f[(f.forecast_cutoff_utc<=f.prediction_created_at_utc)&(f.prediction_created_at_utc<f.kickoff_utc)]
        f=f.sort_values(['prediction_created_at_utc','game_id']).drop_duplicates('game_id')
        truth=games.set_index('game_id')
        for r in f.to_dict('records'):
            if r['game_id'] not in truth.index:continue
            g=truth.loc[r['game_id']]
            if pd.isna(g.home_score) or pd.isna(g.away_score) or g.kickoff_utc+pd.Timedelta(hours=12)>cutoff:continue
            if canonical(g.home_team)!=r['home_team'] or canonical(g.away_team)!=r['away_team']:raise ValueError('All-stats matchup changed')
            if abs((g.kickoff_utc-r['kickoff_utc']).total_seconds())>600:continue
            r['actual_margin']=float(g.home_score-g.away_score)
            if all(np.isfinite(r[c]) for c in ['baseline_predicted_margin','neutral_predicted_margin','all_stats_predicted_margin']):rows.append(r)
    settled=pd.DataFrame(rows,columns=columns)
    settled.to_csv(out/'all_stats_settled.csv',index=False)
    summary={'version':VERSION,'settled_games':len(settled),'scope':'First pregame snapshot per game; all games, no spread threshold','mae':{}}
    for label in ['baseline','neutral','all_stats']:
        summary['mae'][label]=float(np.mean(abs(settled[label+'_predicted_margin']-settled.actual_margin))) if len(settled) else None
    (out/'all_stats_evaluation.json').write_text(json.dumps(summary,indent=2))
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',required=True)
    prepare(ap.parse_args().prepare)
