"""Locked V3 live extension, QB candidate, and gated injury shadow model.
Research forecasts only. No cover probabilities or wagers are produced.
"""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import argparse,json,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
import urllib.request
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from threadpoolctl import threadpool_limits
import model_v3 as base
import model_v3_epa as epa
from data_layer import utc,schedule,SCHEDULE

VERSION='V3_SHADOW_NEUTRAL_STATUS_V2'
COLUMNS=[x for x in base.FEATURES if x not in ['qb_margin_diff','qb_experience_diff']]+epa.EXTRA
GROUPS=['DB','FRONT','OL','QB','RB','REC','ST']
INJURY_COLUMNS=['inj_'+g+'_diff' for g in GROUPS]+['inj_reported_players_diff','inj_out_without_snaps_diff','inj_unresolved_diff']
MIN_INJURY_GAMES=200
THRESHOLD=3.0
BOOK='draftkings'
ROOT=Path(__file__).resolve().parent
FROZEN_SHA='604bf569f3933bd1eaf8d3165b4fe14d810fa4cf3d77c87a8b360b37a8080f98'

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def regressor():
    return make_pipeline(SimpleImputer(strategy='median'),HistGradientBoostingRegressor(max_iter=150,max_leaf_nodes=15,l2_regularization=10,learning_rate=.04,random_state=42))

def frozen_training(cutoff):
    path=ROOT/'historical_features.csv'
    if digest(path)!=FROZEN_SHA:raise ValueError('Locked training features changed')
    f=pd.read_csv(path,float_precision='round_trip')
    if f.game_id.duplicated().any() or not f.season.between(2017,2025).all():raise ValueError('Invalid locked training snapshot')
    if (pd.to_datetime(f.gameday,utc=True)>=utc(cutoff)).any():raise ValueError('Training snapshot contains future games')
    return f

def verify_reference():
    f=frozen_training('2026-11-13T00:00:00Z')
    ref=pd.read_csv(ROOT/'locked_reference_predictions.csv',float_precision='round_trip')
    expected=ref[ref.model.eq('epa_boosted_trees')&ref.season.eq(2025)].set_index('game_id')
    train=f[f.season.lt(2025)];test=f[f.season.eq(2025)].set_index('game_id').loc[expected.index]
    with threadpool_limits(limits=1):
        model=regressor().fit(train[COLUMNS],train.actual_margin)
        p=model.predict(test[COLUMNS])
    difference=float(np.max(np.abs(p-expected.predicted_margin.to_numpy())))
    if difference>1e-6:raise ValueError('Historical reference replay drift: '+str(difference))
    return dict(test_season=2025,games=len(expected),max_abs_margin_difference=difference,training_sha256=FROZEN_SHA)

def current_features(games,teams,qbs,cutoff,neutral_sites=False):
    g=games[games.season.ge(2017)].copy()
    g['gameday']=pd.to_datetime(g.gameday,utc=True)
    # The original score/Elo model used raw schedule team codes. Preserve them
    # until score features are built; EPA canonicalizes internally as before.
    g.loc[g.kickoff_utc+pd.Timedelta(hours=12)>cutoff,['home_score','away_score']]=np.nan
    f=base.make_features(g,neutral_sites=neutral_sites).merge(epa.epa_features(g,teams,qbs),on='game_id',validate='one_to_one')
    for side in ['home','away']:f[side+'_team']=f[side+'_team'].map(epa.canonical)
    f[COLUMNS]=f[COLUMNS].round(10)
    return f

def qb_profile(qid,stats,games,cutoff):
    q=stats[stats.passer_player_id.eq(qid)].merge(games[['game_id','kickoff_utc']],on='game_id',validate='many_to_one')
    q=q[q.kickoff_utc+pd.Timedelta(hours=12)<=cutoff].sort_values(['kickoff_utc','game_id']).tail(8)
    n=float(q.dropbacks.sum())
    return dict(epa=float(q.epa_sum.sum())/(n+100),success=(float(q.success_sum.sum())+50)/(n+100),dropbacks=min(n,400),missing=int(n==0))

def qb_override(features,auto,qbs,games,cutoff):
    out=features.copy();status=[]
    if auto.duplicated(['game_id','team']).any():raise ValueError('Duplicate automatic team features')
    lookup=auto.set_index(['game_id','team'])
    for idx,row in out.iterrows():
        profiles=[];chosen={};reason='ready_depth_chart_only'
        for side in ['home','away']:
            key=(row.game_id,row[side+'_team'])
            if key not in lookup.index:reason='missing_qb_candidate';break
            t=lookup.loc[key]
            if utc(t.feature_cutoff_utc)>cutoff:raise ValueError('Automatic source data is after forecast cutoff')
            if t.qb_candidate_status!='depth_chart_only' or not str(t.qb_candidate_id).strip():reason='uncertain_or_missing_qb_candidate';break
            p=qb_profile(str(t.qb_candidate_id),qbs,games,cutoff)
            if p['missing']:reason='candidate_qb_has_no_prior_sample';break
            profiles.append(p);chosen[side+'_candidate_qb_id']=str(t.qb_candidate_id);chosen[side+'_candidate_qb_name']=t.qb_candidate_name
        if reason=='ready_depth_chart_only':
            h,a=profiles
            for name in ['epa','success','dropbacks']:out.loc[idx,'qb_'+name+'_diff']=h[name]-a[name]
            out.loc[idx,'home_qb_missing']=0;out.loc[idx,'away_qb_missing']=0
        status.append(dict(game_id=row.game_id,qb_candidate_status=reason,**chosen))
    return out,pd.DataFrame(status)

def injury_design(auto,game_id,home,away):
    f=auto[auto.game_id.eq(game_id)].set_index('team')
    if home not in f.index or away not in f.index:return None
    h,a=f.loc[home],f.loc[away]
    if h.injury_feed_status!='observed_partial' or a.injury_feed_status!='observed_partial':return None
    result={}
    for group in GROUPS:result['inj_'+group+'_diff']=h['observed_out_snap_proxy_'+group]-a['observed_out_snap_proxy_'+group]
    for out,name in [('inj_reported_players_diff','injury_players_reported'),('inj_out_without_snaps_diff','known_out_players_without_snap_history'),('inj_unresolved_diff','unresolved_designations')]:result[out]=h[name]-a[name]
    if not all(np.isfinite(float(v)) for v in result.values()):return None
    return {k:float(v) for k,v in result.items()}

def truth(x):return str(x).lower() in ['true','1']

def first_observations(history):
    if history.empty:return history
    h=history[history.strategy_version.eq(VERSION)].copy()
    h['prediction_created_at_utc']=h.prediction_created_at_utc.map(utc)
    h=h[h.decision_eligible.map(truth)&h.qb_predicted_margin.notna()]
    return h.sort_values(['prediction_created_at_utc','snapshot_id']).drop_duplicates('game_id',keep='first')

def settle(history,games,cutoff):
    h=first_observations(history)
    if h.empty:return pd.DataFrame(columns=['game_id','actual_margin','baseline_predicted_margin','qb_predicted_margin','injury_predicted_margin','injury_features_ready']+INJURY_COLUMNS)
    actual=games.set_index('game_id');records=[]
    for row in h.to_dict('records'):
        gid=row['game_id']
        if gid not in actual.index:continue
        g=actual.loc[gid]
        if utc(g.kickoff_utc)+pd.Timedelta(hours=12)>cutoff or pd.isna(g.home_score) or pd.isna(g.away_score):continue
        # Changed start times may mean rescheduling/void rules; do not assume a fill settled.
        if abs((utc(row['kickoff_utc'])-utc(g.kickoff_utc)).total_seconds())>600:continue
        if utc(row['prediction_created_at_utc'])>=utc(g.kickoff_utc):continue
        row['actual_margin']=float(g.home_score-g.away_score);records.append(row)
    return pd.DataFrame(records,columns=list(h.columns)+['actual_margin'])

def fit_injury(settled):
    if settled.empty:return None,dict(status='WAITING_FOR_SETTLED_DATA',eligible_training_games=0,minimum=MIN_INJURY_GAMES)
    t=settled[settled.injury_features_ready.map(truth)].dropna(subset=INJURY_COLUMNS+['qb_predicted_margin','actual_margin']).copy()
    if t.game_id.duplicated().any():raise ValueError('Duplicate games in injury training')
    info=dict(status='WAITING_FOR_SETTLED_DATA',eligible_training_games=len(t),minimum=MIN_INJURY_GAMES)
    if len(t)<MIN_INJURY_GAMES:return None,info
    model=make_pipeline(StandardScaler(),Ridge(alpha=100)).fit(t[INJURY_COLUMNS],t.actual_margin-t.qb_predicted_margin)
    info.update(status='SHADOW_ONLY_NOT_VALIDATED',training_game_ids=sorted(t.game_id.tolist()),training_data_sha256=hashlib.sha256(t.sort_values('game_id')[['game_id']+INJURY_COLUMNS+['qb_predicted_margin','actual_margin']].to_csv(index=False,float_format='%.12g').encode()).hexdigest())
    info.update(alpha=100,standardized_coefficients={k:float(v) for k,v in zip(INJURY_COLUMNS,model.named_steps['ridge'].coef_)},intercept=float(model.named_steps['ridge'].intercept_))
    return model,info

def choice(margin,line):
    if not np.isfinite(margin):return 'blocked'
    edge=float(margin)+float(line)
    return ('home' if edge>0 else 'away') if abs(edge)>=THRESHOLD else 'pass'

def payout(american):
    if not np.isfinite(american) or abs(american)<100:raise ValueError('Invalid American price')
    return american/100 if american>0 else 100/abs(american)

def comparison(settled):
    rows=[]
    for name,column in [('locked_v3','baseline_predicted_margin'),('neutral_candidate','neutral_predicted_margin'),('qb_candidate','qb_predicted_margin'),('qb_injury_shadow','injury_predicted_margin')]:
        valid=settled.dropna(subset=[column]) if len(settled) and column in settled else pd.DataFrame()
        wins=losses=pushes=0;profit=0.;errors=[]
        for r in valid.to_dict('records'):
            errors.append(abs(r[column]-r['actual_margin']))
            side=choice(r[column],r['home_line'])
            if side in ['blocked','pass']:continue
            cover=(r['actual_margin']+r['home_line'])*(1 if side=='home' else -1)
            if np.isclose(cover,0):pushes+=1
            elif cover>0:wins+=1;profit+=payout(r[side+'_odds_american'])
            else:losses+=1;profit-=1
        bets=wins+losses+pushes
        rows.append(dict(model=name,settled_forecasts=len(valid),mae=float(np.mean(errors)) if errors else None,selected_games=bets,wins=wins,losses=losses,pushes=pushes,win_pct=100*wins/(wins+losses) if wins+losses else None,hypothetical_profit_per_unit_risked=profit if bets else None,hypothetical_roi_pct=100*profit/bets if bets else None))
    return pd.DataFrame(rows)

def load_history(archive):
    frames=[]
    for path in sorted((Path(archive)/'data/shadow_predictions').glob('*/game_predictions.csv')):
        manifest_path=path.parent/'manifest.json'
        if not manifest_path.exists():raise ValueError('Prediction archive is missing its manifest')
        manifest=json.loads(manifest_path.read_text())
        if manifest.get('files',{}).get('game_predictions.csv')!=digest(path):raise ValueError('Prediction ledger checksum mismatch')
        if path.stat().st_size>1:frames.append(pd.read_csv(path))
    return pd.concat(frames,ignore_index=True) if frames else pd.DataFrame()

def load_live_pbp(season,out,local=None,all_stats=False):
    if local:path=Path(local)
    else:
        path=Path(out)/f'play_by_play_{season}.parquet'
        with urllib.request.urlopen(epa.PBP_URL.format(season=season),timeout=120) as response:path.write_bytes(response.read())
    columns=['game_id','posteam','defteam','epa','play_type','qb_dropback','rush_attempt','qb_kneel','qb_spike','passer_player_id','passer_id','qb_epa']
    if all_stats:
        from all_stats import aggregate, PBP_COLUMNS
        aggregate(pd.read_parquet(path,columns=PBP_COLUMNS)).to_csv(Path(out)/'all_stats_live_counts.csv',index=False)
    teams,qbs=epa.aggregate_pbp(pd.read_parquet(path,columns=columns))
    return teams,qbs,dict(season=season,url=epa.PBP_URL.format(season=season),sha256=digest(path),captured_at_utc=datetime.now(timezone.utc).isoformat(),local_replay=bool(local))

def raw_schedule(path):
    raw=pd.read_csv(path,low_memory=False)
    g=schedule(path)
    # Retain raw schedule franchise codes for exact score/Elo recipe continuity.
    g['home_team']=raw.home_team;g['away_team']=raw.away_team
    return g

def evaluate(args):
    out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
    path=out/'outcome_schedule.csv'
    if args.schedule:
        path.write_bytes(Path(args.schedule).read_bytes())
    else:
        with urllib.request.urlopen(SCHEDULE,timeout=60) as response:path.write_bytes(response.read())
    cutoff=utc(datetime.now(timezone.utc).isoformat())
    settled=settle(load_history(args.archive),raw_schedule(path),cutoff)
    _,injury_info=fit_injury(settled)
    settled.to_csv(out/'settled_first_observations.csv',index=False)
    comparison(settled).to_csv(out/'comparison.csv',index=False)
    from compare_all_games import compare
    compare(args.archive,path,cutoff).to_csv(out/'all_games_settled.csv',index=False)
    from compare_verified_qb import compare as compare_starters,summary as starter_summary
    starter_settled=compare_starters(args.archive,raw_schedule(path),cutoff)
    starter_settled.to_csv(out/'qb_starters_settled.csv',index=False)
    (out/'qb_starters_summary.json').write_text(json.dumps(starter_summary(starter_settled),indent=2))
    from all_stats import evaluate_archive
    evaluate_archive(args.archive,raw_schedule(path),cutoff,out)
    common=settled.dropna(subset=['injury_predicted_margin']) if len(settled) else settled
    comparison(common).to_csv(out/'comparison_injury_common.csv',index=False)
    manifest=dict(status='EVALUATION_ONLY',created_at_utc=cutoff.isoformat(),strategy_version=VERSION,paired_settled_games=len(settled),injury_model=injury_info,odds_requests=0,files={p.name:digest(p) for p in out.iterdir() if p.is_file()},limits=['Recorded prices are not verified fills.','No new forecasts are issued by evaluate mode.'])
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({k:manifest[k] for k in ['status','paired_settled_games','odds_requests']}))

def run(args):
    out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
    data=Path(args.data);avail=data/'availability';auto_dir=data/'auto_reports'
    replay=verify_reference();(out/'reference_replay.json').write_text(json.dumps(replay,indent=2))
    games=raw_schedule(avail/'schedule.csv')
    auto=pd.read_csv(auto_dir/'team_features.csv',keep_default_na=False)
    for c in ['observed_out_snap_proxy_'+p for p in GROUPS]+['injury_players_reported','known_out_players_without_snap_history','unresolved_designations']:auto[c]=pd.to_numeric(auto[c],errors='coerce')
    auto_manifest=json.loads((auto_dir/'source_manifest.json').read_text())
    feature_cutoff=utc(datetime.now(timezone.utc).isoformat())
    if utc(auto_manifest['feature_cutoff_utc'])>feature_cutoff:raise ValueError('Future automatic report snapshot')
    if feature_cutoff-utc(auto_manifest['feature_cutoff_utc'])>pd.Timedelta(minutes=15):raise ValueError('Automatic report snapshot is stale; run a fresh capture')
    target_ids=set(auto.game_id)
    seasons=games[games.game_id.isin(target_ids)].season.unique()
    if len(seasons)!=1 or int(seasons[0])<=2025:raise ValueError('Candidate needs one live season later than locked 2025 training')
    live_t,live_q,live_source=load_live_pbp(int(seasons[0]),out,args.pbp,all_stats=bool(getattr(args,'all_stats_cache',None)))
    feature_cutoff=utc(datetime.now(timezone.utc).isoformat())
    teams=pd.concat([pd.read_csv(ROOT/'historical_team_stats.csv.gz'),live_t],ignore_index=True)
    qbs=pd.concat([pd.read_csv(ROOT/'historical_qb_stats.csv.gz'),live_q],ignore_index=True)
    if teams.duplicated(['game_id','posteam','defteam']).any() or qbs.duplicated(['game_id','posteam','passer_player_id']).any():raise ValueError('Historical/live PBP overlap')
    features=current_features(games,teams,qbs,feature_cutoff)
    selected=features[features.season.eq(int(seasons[0]))&features.kickoff_utc.gt(feature_cutoff)&features.kickoff_utc.le(feature_cutoff+pd.Timedelta(days=7))].copy()
    selected_qb,status=qb_override(selected,auto,qbs,games,feature_cutoff)
    # Rebuild the candidate's training AND live Elo history with the same venue rule.
    neutral_features=current_features(games,teams,qbs,feature_cutoff,neutral_sites=True)
    neutral_train=neutral_features[neutral_features.season.between(2017,2025)&neutral_features.actual_margin.notna()]
    neutral_live=neutral_features[neutral_features.game_id.isin(selected.game_id)].copy()
    with threadpool_limits(limits=1):
        neutral_model=regressor().fit(neutral_train[COLUMNS],neutral_train.actual_margin)
        neutral_live['neutral_predicted_margin']=neutral_model.predict(neutral_live[COLUMNS]) if len(neutral_live) else []
    selected=selected.merge(neutral_live[['game_id','neutral_predicted_margin','home_field']].rename(columns={'home_field':'candidate_home_field'}),on='game_id',validate='one_to_one')

    hist=frozen_training(feature_cutoff)
    with threadpool_limits(limits=1):
        model=regressor().fit(hist[COLUMNS],hist.actual_margin)
        selected['baseline_predicted_margin']=model.predict(selected[COLUMNS]) if len(selected) else []
        selected_qb['qb_predicted_margin']=model.predict(selected_qb[COLUMNS]) if len(selected_qb) else []
    selected=selected.merge(status,on='game_id',validate='one_to_one')
    selected=selected.merge(selected_qb[['game_id','qb_predicted_margin']],on='game_id',validate='one_to_one')
    selected.loc[~selected.qb_candidate_status.eq('ready_depth_chart_only'),'qb_predicted_margin']=np.nan
    # Every scheduled game is recorded even when no usable market quote exists.
    from forecast_status import forecast_status
    status_report=forecast_status(selected,auto,games,teams,feature_cutoff)
    status_report.to_csv(out/'all_game_forecasts.csv',index=False)
    from verified_qb import read_confirmations,scenarios
    confirmation_path=getattr(args,'qb_confirmations',None)
    starter_evidence=read_confirmations(Path(confirmation_path) if confirmation_path else None)
    starter_evidence.to_csv(out/'starter_evidence.csv',index=False)
    with threadpool_limits(limits=1):
        starter_scenarios=scenarios(selected,auto,starter_evidence,qbs,games,feature_cutoff,model,COLUMNS)
    starter_scenarios.to_csv(out/'qb_starter_scenarios.csv',index=False)
    history=load_history(args.archive)
    settled=settle(history,games,feature_cutoff)
    injury_model,injury_info=fit_injury(settled)
    quotes=pd.read_csv(avail/'matched_quotes.csv')
    quotes=quotes[quotes.sportsbook.eq(BOOK)]
    created=utc(datetime.now(timezone.utc).isoformat())
    snapshot_id=hashlib.sha256((created.isoformat()+FROZEN_SHA+digest(__file__)).encode()).hexdigest()[:24]
    records=[]
    for f in selected.to_dict('records'):
        q=quotes[quotes.game_id.eq(f['game_id'])]
        if len(q)!=2 or set(q.side)!=set(['home','away']):continue
        h=q[q.side.eq('home')].iloc[0];a=q[q.side.eq('away')].iloc[0]
        captured=utc(h.captured_at_utc);kick=utc(h.kickoff_utc)
        if created<captured or created-captured>pd.Timedelta(minutes=15) or kick<=created:continue
        if utc(a.captured_at_utc)!=captured or utc(a.kickoff_utc)!=kick or not np.isclose(h.line,-a.line):raise ValueError('Mismatched two-sided quote')
        if abs((utc(f['kickoff_utc'])-kick).total_seconds())>600:raise ValueError('Forecast/quote kickoff mismatch')
        inj=injury_design(auto,f['game_id'],f['home_team'],f['away_team'])
        bm=float(f['baseline_predicted_margin']);qm=float(f['qb_predicted_margin']);im=np.nan
        if injury_model is not None and inj is not None and np.isfinite(qm):im=qm+float(injury_model.predict(pd.DataFrame([inj])[INJURY_COLUMNS])[0])
        row=dict(strategy_version=VERSION,snapshot_id=snapshot_id,game_id=f['game_id'],home_team=f['home_team'],away_team=f['away_team'],kickoff_utc=kick.isoformat(),prediction_created_at_utc=created.isoformat(),feature_cutoff_utc=feature_cutoff.isoformat(),quote_captured_at_utc=captured.isoformat(),sportsbook=BOOK,home_line=float(h.line),home_odds_american=float(h.odds_american),away_odds_american=float(a.odds_american),neutral_predicted_margin=float(f['neutral_predicted_margin']),baseline_predicted_margin=bm,qb_predicted_margin=qm,injury_predicted_margin=im,qb_candidate_status=f['qb_candidate_status'],decision_eligible=bool(pd.Timedelta(hours=1)<=kick-created<=pd.Timedelta(days=7)),injury_features_ready=inj is not None,baseline_selection=choice(bm,h.line),qb_selection=choice(qm,h.line),injury_selection=choice(im,h.line),status='RESEARCH_ONLY_UNVALIDATED')
        for side in ['home','away']:
            row[side+'_candidate_qb_id']=f.get(side+'_candidate_qb_id','');row[side+'_candidate_qb_name']=f.get(side+'_candidate_qb_name','')
        row.update(inj or {k:None for k in INJURY_COLUMNS});records.append(row)
    columns=list(records[0]) if records else ['strategy_version','snapshot_id','game_id','prediction_created_at_utc','decision_eligible','baseline_predicted_margin','qb_predicted_margin','injury_predicted_margin','injury_features_ready']+INJURY_COLUMNS
    ledger=pd.DataFrame(records,columns=columns);ledger.to_csv(out/'game_predictions.csv',index=False)
    selected.to_csv(out/'baseline_live_features.csv',index=False);selected_qb.to_csv(out/'qb_live_features.csv',index=False)
    settled.to_csv(out/'settled_first_observations.csv',index=False);comparison(settled).to_csv(out/'comparison.csv',index=False)
    injury_common=settled.dropna(subset=['injury_predicted_margin']) if len(settled) else settled
    comparison(injury_common).to_csv(out/'comparison_injury_common.csv',index=False)
    # Save aggregate observations, not an ever-growing raw parquet on GitHub.
    live_t.to_csv(out/'live_team_stats.csv.gz',index=False,compression='gzip');live_q.to_csv(out/'live_qb_stats.csv.gz',index=False,compression='gzip')
    if not args.pbp:(out/f'play_by_play_{int(seasons[0])}.parquet').unlink()
    all_stats_info=None
    if getattr(args,'all_stats_cache',None):
        from all_stats import add_candidate
        all_stats_info=add_candidate(games,neutral_features,selected,pd.read_csv(out/'all_stats_live_counts.csv'),feature_cutoff,args.all_stats_cache,out,auto,starter_evidence,qbs)
    manifest=dict(strategy_version=VERSION,created_at_utc=created.isoformat(),status='PROSPECTIVE_RESEARCH_ONLY' if len(selected) else 'NO_FRESH_FORECASTS',scheduled_forecast_games=len(selected),prediction_games=len(ledger),qb_ready_games=int(ledger.qb_predicted_margin.notna().sum()),paired_settled_games=len(settled),injury_model=injury_info,reference_replay=replay,training_through_season=2025,model_parameters=model.named_steps['histgradientboostingregressor'].get_params(),feature_columns=COLUMNS,source_pbp=live_source,starter_candidate=dict(version='STARTER_SCENARIOS_V1',confirmation_file_present=bool(confirmation_path and Path(confirmation_path).exists()),scenario_rows=len(starter_scenarios),confirmed_games=int(starter_scenarios.loc[starter_scenarios.scenario_status.eq('CONFIRMED_STARTER_CANDIDATE'),'game_id'].nunique()),evidence_policy='Source content must be checked before entry; code validates schema, timing and conflicts, not the factual claim on the linked page.'),rule=dict(book=BOOK,minimum_edge_points=THRESHOLD,earliest_hours_before_kickoff=168,latest_hours_before_kickoff=1,record_policy='first eligible paired baseline/QB snapshot per game',unit_risk=1),files={p.name:digest(p) for p in out.iterdir() if p.is_file()},code_sha256=digest(__file__),limits=['Locked historical artifacts are unchanged; live extension uses frozen training and newly observed histories.','Historical 2020-2025 results remain exploratory; no new backtest win-rate claim.','QB candidates are unconfirmed and changing QB features has unvalidated distribution shift.','Injury shadow model waits for 200 eligible settled, prospectively recorded games.','Injury data is partial and snap shares are proxies; IR coverage is missing.','Reported ROI uses recorded provider prices, not verified fills, and does not include account restrictions.','No cover probabilities or wagers are produced.'])
    manifest['all_stats_candidate']=all_stats_info
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2,default=str))
    print(json.dumps({k:manifest[k] for k in ['status','prediction_games','qb_ready_games','paired_settled_games','injury_model']},default=str))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--data');ap.add_argument('--all-stats-cache',help='Verified extended-stat aggregate cache; enables ALL_STATS_V1 candidate');ap.add_argument('--qb-confirmations',help='CSV of source-checked, timestamped starter reports; absent file leaves all candidates unconfirmed');ap.add_argument('--archive',required=True);ap.add_argument('--out',required=True);ap.add_argument('--pbp',help='Local current-season parquet for replay');ap.add_argument('--evaluate',action='store_true');ap.add_argument('--schedule',help='Local outcome schedule for evaluation replay')
    args=ap.parse_args()
    if args.evaluate:evaluate(args)
    elif not args.data:ap.error('--data is required for forecast mode')
    else:run(args)
