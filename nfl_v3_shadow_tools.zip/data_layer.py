"""Prospective NFL data collection. No trained injury adjustment or wagering advice."""
import argparse
import hashlib
import json
import math
import shutil
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
import urllib.request
import pandas as pd
from odds import utc, TEAMS, normalize

QB_COLS = 'game_id team scenario_set_id qb_id start_probability announced_at_utc recorded_at_utc source_url'.split()
INJ_COLS = 'game_id team player_id position availability_probability baseline_snap_share announced_at_utc recorded_at_utc source_url'.split()
COV_COLS = 'game_id team report_complete announced_at_utc recorded_at_utc source_url'.split()
GROUPS = {'QB':'QB','T':'OL','OT':'OL','G':'OL','OG':'OL','C':'OL','OL':'OL','WR':'REC','TE':'REC','RB':'RB','FB':'RB','CB':'DB','S':'DB','FS':'DB','SS':'DB','DB':'DB','DE':'FRONT','DT':'FRONT','NT':'FRONT','LB':'FRONT','ILB':'FRONT','OLB':'FRONT','EDGE':'FRONT','DL':'FRONT','K':'ST','P':'ST','LS':'ST'}
SCHEDULE = 'https://raw.githubusercontent.com/nflverse/nfldata/master/data/games.csv'

def ledger(path, columns):
    f = pd.read_csv(path, keep_default_na=False, dtype=str) if Path(path).exists() else pd.DataFrame(columns=columns)
    if set(columns) - set(f):
        raise ValueError(f'{path}: required columns: {columns}')
    return f[columns]

def reports_asof(frame, cutoff, games, idcols):
    """Future reports are withheld; malformed chronology/unknown games fail closed."""
    f = frame.copy()
    if f.empty:
        return f
    for c in idcols + ['source_url']:
        if f[c].str.strip().eq('').any():
            raise ValueError(f'Blank report field: {c}')
    if not f.source_url.str.match(r'^https?://[^/\s]+').all():
        raise ValueError('A report requires a source URL')
    for c in ['announced_at_utc', 'recorded_at_utc']:
        f[c] = f[c].map(utc)
    if (f.announced_at_utc > f.recorded_at_utc).any():
        raise ValueError('Report announcement is after recorded time')
    lookup = games.set_index('game_id')
    kicks = f.game_id.map(lookup.kickoff_utc)
    if kicks.isna().any():
        raise ValueError('Report references unknown game')
    teams = {r.game_id:{r.home_team,r.away_team} for r in games.itertuples()}
    if any(r.team not in teams[r.game_id] for r in f.itertuples()):
        raise ValueError('Report team does not match game')
    return f[(f.recorded_at_utc <= cutoff) & (f.recorded_at_utc < kicks) & (f.announced_at_utc < kicks)].copy()

def numeric(f, columns):
    for c in columns:
        f[c] = pd.to_numeric(f[c], errors='raise')
        if not f[c].map(lambda x: math.isfinite(x) and 0 <= x <= 1).all():
            raise ValueError(f'{c} must be finite and between 0 and 1')
    return f

def availability(games, qbs, injuries, coverage, cutoff):
    cutoff = utc(cutoff)
    q = numeric(reports_asof(qbs,cutoff,games,['game_id','team','scenario_set_id','qb_id']),['start_probability'])
    inj = numeric(reports_asof(injuries,cutoff,games,['game_id','team','player_id','position']),['availability_probability','baseline_snap_share'])
    cov = reports_asof(coverage,cutoff,games,['game_id','team'])
    if not inj.empty and not inj.position.isin(GROUPS).all():
        raise ValueError('Unknown position; use a supported football position code')
    rows=[]; scenarios=[]
    for game in games.itertuples():
        if game.kickoff_utc <= cutoff:
            continue
        for team in [game.home_team,game.away_team]:
            row=dict(game_id=game.game_id,team=team,feature_cutoff_utc=cutoff.isoformat(),qb_status='missing',injury_status='missing',qb_max_start_probability=None,qb_scenario_count=0,qb_report_age_hours=None,injury_report_age_hours=None)
            sq=q[q.game_id.eq(game.game_id)&q.team.eq(team)]
            if not sq.empty:
                # Each update is a complete distribution; never combine a new starter
                # probability with a stale backup probability from an earlier report.
                sets=sq.groupby('scenario_set_id').recorded_at_utc.max()
                latest=sets[sets.eq(sets.max())]
                if len(latest)!=1:
                    raise ValueError('Ambiguous simultaneous QB scenario sets')
                sq=sq[sq.scenario_set_id.eq(latest.index[0])]
                if sq.qb_id.duplicated().any() or sq.recorded_at_utc.nunique()!=1 or sq.announced_at_utc.nunique()!=1:
                    raise ValueError('QB scenario set must be complete, unique and timestamp-consistent')
                if not math.isclose(sq.start_probability.sum(),1,abs_tol=1e-8):
                    raise ValueError('QB starter probabilities must sum to 1 per team/scenario set')
                row.update(qb_status='ready',qb_max_start_probability=float(sq.start_probability.max()),qb_scenario_count=len(sq))
                row['qb_report_age_hours']=(cutoff-sq.recorded_at_utc.max()).total_seconds()/3600
                scenarios.extend(sq.to_dict('records'))
            si=inj[inj.game_id.eq(game.game_id)&inj.team.eq(team)].sort_values('recorded_at_utc')
            if si.duplicated(['player_id','recorded_at_utc']).any():
                raise ValueError('Ambiguous simultaneous injury updates')
            si=si.drop_duplicates('player_id',keep='last')
            sc=cov[cov.game_id.eq(game.game_id)&cov.team.eq(team)].sort_values('recorded_at_utc')
            complete=False
            if not sc.empty:
                if sc.recorded_at_utc.duplicated().any():
                    raise ValueError('Ambiguous simultaneous coverage reports')
                last=sc.iloc[-1]
                if last.report_complete.lower() not in ['true','false']:
                    raise ValueError('report_complete must be true or false')
                # A completeness assertion must follow all its player entries.
                complete=last.report_complete.lower()=='true' and (si.empty or last.recorded_at_utc >= si.recorded_at_utc.max())
                row['injury_status']='complete' if complete else 'partial'
                row['injury_report_age_hours']=(cutoff-last.recorded_at_utc).total_seconds()/3600
            elif not si.empty:
                row['injury_status']='partial'
            row['injury_players_reported']=len(si)
            for group in sorted(set(GROUPS.values())):
                sg=si[si.position.map(GROUPS).eq(group)]
                # A sum of expected lost snap shares, NOT a points adjustment.
                row['missing_snap_equivalents_'+group]=float(((1-sg.availability_probability)*sg.baseline_snap_share).sum()) if complete else None
            rows.append(row)
    columns='game_id team feature_cutoff_utc qb_status injury_status qb_max_start_probability qb_scenario_count qb_report_age_hours injury_report_age_hours injury_players_reported'.split()+['missing_snap_equivalents_'+g for g in sorted(set(GROUPS.values()))]
    return pd.DataFrame(rows,columns=columns),pd.DataFrame(scenarios,columns=QB_COLS)

def game_features(games, features):
    """One row per game, ready for a later training join on game_id."""
    rows=[]
    if features.empty:
        return pd.DataFrame(columns=['game_id','feature_cutoff_utc','availability_complete'])
    lookup=features.set_index(['game_id','team'])
    for game in games.itertuples():
        h=lookup.loc[(game.game_id,game.home_team)]
        a=lookup.loc[(game.game_id,game.away_team)]
        row=dict(game_id=game.game_id,feature_cutoff_utc=h.feature_cutoff_utc,availability_complete=h.qb_status=='ready' and a.qb_status=='ready' and h.injury_status=='complete' and a.injury_status=='complete')
        for side,f in [('home',h),('away',a)]:
            for key,value in f.items():
                if key!='feature_cutoff_utc':row[side+'_'+key]=value
        for group in sorted(set(GROUPS.values())):
            key='missing_snap_equivalents_'+group
            row[key+'_diff']=h[key]-a[key] if pd.notna(h[key]) and pd.notna(a[key]) else None
        rows.append(row)
    return pd.DataFrame(rows)

def schedule(path):
    f=pd.read_csv(path)
    times=pd.to_datetime(f.gameday.astype(str).str[:10]+' '+f.gametime.astype(str),format='%Y-%m-%d %H:%M',errors='coerce')
    f['kickoff_utc']=times.dt.tz_localize('America/New_York',ambiguous='raise',nonexistent='raise').dt.tz_convert('UTC')
    for c in ['home_team','away_team']:
        f[c]=f[c].replace({'OAK':'LV','SD':'LAC','STL':'LAR','LA':'LAR'})
    if f.game_id.duplicated().any():
        raise ValueError('Duplicate schedule game IDs')
    return f

def match(quotes, games, *, quarantine=False):
    rows=[];unmatched=[]
    for r in quotes.itertuples():
        matches=games[games.home_team.eq(r.home_team)&games.away_team.eq(r.away_team)&((games.kickoff_utc-utc(r.kickoff_utc)).abs()<=pd.Timedelta(minutes=10))]
        if len(matches)!=1:
            if not quarantine:
                raise ValueError('Odds event has no unique schedule match')
            candidates=games[games.home_team.eq(r.home_team)&games.away_team.eq(r.away_team)].copy()
            candidates['delta_minutes']=(candidates.kickoff_utc-utc(r.kickoff_utc)).abs().dt.total_seconds()/60
            candidates=candidates.sort_values('delta_minutes').head(3)
            unmatched.append(dict(event_id=r.event_id,home_team=r.home_team,away_team=r.away_team,kickoff_utc=str(r.kickoff_utc),reason='ambiguous_schedule_match' if len(matches)>1 else 'no_schedule_match',candidates=[dict(game_id=c.game_id,kickoff_utc=str(c.kickoff_utc),delta_minutes=float(c.delta_minutes) if pd.notna(c.delta_minutes) else None) for c in candidates.itertuples()]))
            continue
        row=r._asdict();row.pop('Index',None);row['game_id']=matches.iloc[0].game_id;rows.append(row)
    out=pd.DataFrame(rows,columns=list(quotes.columns)+['game_id'])
    # attrs carries diagnostics without changing the legacy strict-call interface.
    out.attrs['unmatched_events']=list({json.dumps(x,sort_keys=True):x for x in unmatched}.values())
    return out

def archive_capture(capture, archive):
    """Content-addressed raw snapshots plus transactional, idempotent quote index."""
    capture,archive=Path(capture),Path(archive)
    raw=(capture/'provider_response.json').read_bytes()
    meta=json.loads((capture/'capture.json').read_text())
    if hashlib.sha256(raw).hexdigest()!=meta['response_sha256']:
        raise ValueError('Raw odds response checksum mismatch')
    quotes,rejections=normalize(json.loads(raw),meta['captured_at_utc'])
    digest=hashlib.sha256(raw+meta['captured_at_utc'].encode()).hexdigest()
    dest=archive/'captures'/digest
    dest.parent.mkdir(parents=True,exist_ok=True)
    if not dest.exists():
        shutil.copytree(capture,dest)
    else:
        if (dest/'provider_response.json').read_bytes()!=raw or json.loads((dest/'capture.json').read_text())!=meta:
            raise ValueError('Conflicting capture at existing archive path')
    with sqlite3.connect(archive/'odds.sqlite') as db:
        db.execute('CREATE TABLE IF NOT EXISTS captures (id TEXT PRIMARY KEY, captured_at_utc TEXT, response_sha256 TEXT, accepted_quotes INTEGER)')
        db.execute('CREATE TABLE IF NOT EXISTS quotes (capture_id TEXT, event_id TEXT, sportsbook TEXT, side TEXT, kickoff_utc TEXT, line REAL, odds_american INTEGER, quote_updated_at_utc TEXT, PRIMARY KEY(capture_id,event_id,sportsbook,side))')
        present=db.execute('SELECT 1 FROM captures WHERE id=?',(digest,)).fetchone()
        if not present:
            db.execute('INSERT INTO captures VALUES (?,?,?,?)',(digest,meta['captured_at_utc'],meta['response_sha256'],len(quotes)))
            db.executemany('INSERT INTO quotes VALUES (?,?,?,?,?,?,?,?)',[(digest,r.event_id,r.sportsbook,r.side,r.kickoff_utc,r.line,r.odds_american,r.quote_updated_at_utc) for r in quotes.itertuples()])
    return digest,quotes

def run(args):
    # Archive raw odds even if later availability processing fails.
    digest,quotes=archive_capture(args.capture,args.archive)
    cutoff=utc(datetime.now(timezone.utc).isoformat())
    out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
    sp=out/'schedule.csv'
    if args.schedule:
        shutil.copyfile(args.schedule,sp)
    else:
        with urllib.request.urlopen(SCHEDULE,timeout=45) as response:
            sp.write_bytes(response.read())
    games=schedule(sp)
    quotes=match(quotes,games,quarantine=True)
    unmatched=quotes.attrs.get('unmatched_events',[])
    (out/'unmatched_events.json').write_text(json.dumps(unmatched,indent=2))
    quotes.to_csv(out/'matched_quotes.csv',index=False)
    fresh=quotes[quotes.captured_at_utc.map(utc).ge(cutoff-pd.Timedelta(minutes=15)) & quotes.captured_at_utc.map(utc).le(cutoff)]
    upcoming=games[games.game_id.isin(fresh.game_id)&games.kickoff_utc.gt(cutoff)]
    inputdir=Path(args.inputs)
    frames=[ledger(inputdir/name,cols) for name,cols in [('qb_scenarios.csv',QB_COLS),('injuries.csv',INJ_COLS),('injury_coverage.csv',COV_COLS)]]
    for frame,name in zip(frames,['qb_scenarios.csv','injuries.csv','injury_coverage.csv']):
        frame.to_csv(out/name,index=False)
    # Retained ledgers can contain earlier games. Validate them against the full
    # schedule before selecting the games in this capture.
    frames=[reports_asof(frame,cutoff,games,ids) for frame,ids in zip(frames,[['game_id','team','scenario_set_id','qb_id'],['game_id','team','player_id','position'],['game_id','team']])]
    frames=[frame[frame.game_id.isin(upcoming.game_id)].copy() for frame in frames]
    features,scenarios=availability(upcoming,*frames,cutoff)
    features.to_csv(out/'availability_features.csv',index=False)
    game_features(upcoming,features).to_csv(out/'game_features.csv',index=False)
    scenarios.to_csv(out/'selected_qb_scenarios.csv',index=False)
    teams=[{'game_id':r.game_id,'team':t} for r in upcoming.itertuples() for t in [r.home_team,r.away_team]]
    for name,cols in [('qb_scenarios',QB_COLS),('injuries',INJ_COLS),('injury_coverage',COV_COLS)]:
        template=pd.DataFrame(teams).reindex(columns=cols) if teams else pd.DataFrame(columns=cols)
        template.to_csv(out/(name+'_to_fill.csv'),index=False)
    manifest=dict(status='DATA_COLLECTION_ONLY' if len(upcoming) else 'NO_MATCHED_UPCOMING_GAMES',created_at_utc=cutoff.isoformat(),capture_id=digest,matched_quote_rows=len(quotes),unmatched_events=len(unmatched),teams=len(features),ready_teams=int(((features.qb_status=='ready')&(features.injury_status=='complete')).sum()) if len(features) else 0,
                  schedule_sha256=hashlib.sha256(sp.read_bytes()).hexdigest(),files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()},
                  limits=['Manual reports and probabilities are source claims, not authenticated facts.','Injury features have no fitted effect on spread or cover probability.','No model improvement or betting performance has been established.','Blank injury features mean unknown, not healthy.','Capture does not establish an executable wager fill.'])
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    target=Path(args.archive)/'availability'/hashlib.sha256((digest+cutoff.isoformat()).encode()).hexdigest()
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(out,target)
    print(json.dumps({k:manifest[k] for k in ['status','matched_quote_rows','unmatched_events','teams','ready_teams']}))
    if unmatched:
        print('WARNING: Unmatched events were archived but excluded from features. Review unmatched_events.json; game identities and kickoff times were not guessed.')

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    for name in ['capture','archive','inputs','out']:
        ap.add_argument('--'+name,required=True)
    ap.add_argument('--schedule')
    run(ap.parse_args())
