"""Descriptive forecast audit; unknown sources are never called confirmed or fresh."""
import pandas as pd

def forecast_status(features, auto, games, teams, cutoff):
    cutoff=pd.Timestamp(cutoff)
    if auto.duplicated(['game_id','team']).any():raise ValueError('Duplicate team status')
    lookup=auto.set_index(['game_id','team'])
    records=[]
    for f in features.to_dict('records'):
        row={k:f.get(k) for k in ['game_id','home_team','away_team','kickoff_utc','baseline_predicted_margin','neutral_predicted_margin','qb_predicted_margin','qb_candidate_status','candidate_home_field']}
        row.update(forecast_cutoff_utc=cutoff.isoformat(),injury_adjustment_applied=False,injury_adjustment_status='WAITING_FOR_VALIDATED_INJURY_MODEL',venue_status='neutral' if f['candidate_home_field']==0 else 'home')
        for side in ['home','away']:
            team=f[side+'_team']; key=(f['game_id'],team)
            row[side+'_qb_confirmation']='UNCONFIRMED'
            row[side+'_injury_feed_status']='MISSING'
            row[side+'_report_age_hours']=None
            if key in lookup.index:
                t=lookup.loc[key]
                row[side+'_injury_feed_status']=t.get('injury_feed_status','UNKNOWN')
                observed=pd.to_datetime(t.get('feature_cutoff_utc'),utc=True,errors='coerce')
                if pd.notna(observed):
                    if observed>cutoff:raise ValueError('Future report timestamp')
                    row[side+'_report_age_hours']=(cutoff-observed).total_seconds()/3600
            # Dates describe actual observed PBP coverage, not the download time.
            ids=set(teams.loc[teams.posteam.eq(team),'game_id'])
            covered=games[games.game_id.isin(ids)&(games.kickoff_utc+pd.Timedelta(hours=12)<=cutoff)]
            completed=games[((games.home_team.eq(team))|(games.away_team.eq(team)))&games.home_score.notna()&games.away_score.notna()&(games.kickoff_utc+pd.Timedelta(hours=12)<=cutoff)]
            latest=covered.kickoff_utc.max(); expected=completed.kickoff_utc.max()
            row[side+'_pbp_through_utc']=latest.isoformat() if pd.notna(latest) else None
            row[side+'_pbp_coverage_status']='MISSING' if pd.isna(latest) else ('BEHIND_COMPLETED_SCHEDULE' if pd.notna(expected) and latest<expected else 'THROUGH_LATEST_COMPLETED_GAME')
        records.append(row)
    return pd.DataFrame(records)
