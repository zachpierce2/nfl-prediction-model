"""Source-attributed starter scenarios evaluated with the locked V3 estimator.
No depth-chart entry is automatically called confirmed. No point deduction is invented.
"""
from itertools import product
from urllib.parse import urlparse
import numpy as np
import pandas as pd

REQUIRED=['game_id','team','qb_id','qb_name','status','source_url','published_at_utc','observed_at_utc']
VERSION='STARTER_SCENARIOS_V1'
SCHEMA=['starter_strategy_version','game_id','home_team','away_team','forecast_cutoff_utc','kickoff_utc','home_qb_id','away_qb_id','home_qb_name','away_qb_name','home_verification','away_verification','home_source_url','away_source_url','home_source_published_at_utc','away_source_published_at_utc','home_source_observed_at_utc','away_source_observed_at_utc','home_reference_qb_id','away_reference_qb_id','home_epa_vs_reference','away_epa_vs_reference','baseline_predicted_margin','scenario_predicted_margin','adjustment_points','scenario_status','both_starters_confirmed']
MAX_REPORT_AGE_HOURS=24

def read_confirmations(path):
    if path is None or not path.exists():return pd.DataFrame(columns=REQUIRED)
    data=pd.read_csv(path,keep_default_na=False,dtype=str)
    missing=set(REQUIRED)-set(data)
    if missing:raise ValueError('Starter file missing columns: '+str(sorted(missing)))
    return data

def validate(data,cutoff,games):
    from model_v3_epa import canonical
    if data.empty:return data.copy()
    d=data.copy()
    if set(REQUIRED)-set(d):raise ValueError('Starter evidence schema incomplete')
    for col in REQUIRED:
        if d[col].isna().any() or d[col].astype(str).str.strip().eq('').any():raise ValueError('Blank starter evidence: '+col)
    d['team']=d.team.map(canonical)
    if not d.status.isin(['confirmed','expected','scenario']).all():raise ValueError('Unknown starter evidence status')
    for col in ['published_at_utc','observed_at_utc']:
        # Explicit offsets are required; naive times are not reliable evidence.
        if not d[col].astype(str).str.contains(r'(?:Z|[+-]\d{2}:?\d{2})$',regex=True).all():raise ValueError('Starter evidence needs timezone-aware timestamps')
        d[col]=pd.to_datetime(d[col],utc=True,errors='raise')
        if d[col].gt(cutoff).any():raise ValueError('Starter evidence is after forecast cutoff')
    if d.published_at_utc.gt(d.observed_at_utc).any():raise ValueError('Source was observed before publication')
    if not d.source_url.map(lambda x:urlparse(str(x)).scheme=='https' and bool(urlparse(str(x)).netloc)).all():raise ValueError('Starter evidence needs HTTPS source URLs')
    lookup=games.set_index('game_id')
    for r in d.itertuples():
        if r.game_id not in lookup.index:raise ValueError('Unknown game in starter evidence')
        g=lookup.loc[r.game_id]
        if r.team not in [canonical(g.home_team),canonical(g.away_team)]:raise ValueError('Starter team is not in this game')
        if r.observed_at_utc>=g.kickoff_utc:raise ValueError('Starter evidence is not pre-kickoff')
    # Exact duplicate imports are harmless; contradictory simultaneous facts are not.
    d=d.drop_duplicates(REQUIRED)
    confirmed=d[d.status.eq('confirmed')]
    if confirmed.groupby(['game_id','team','observed_at_utc']).qb_id.nunique().gt(1).any():raise ValueError('Conflicting simultaneous starter confirmations')
    return d

def reference_qb(team,qbs,games,cutoff):
    from model_v3_epa import canonical
    q=qbs[qbs.posteam.map(canonical).eq(team)].merge(games[['game_id','kickoff_utc','home_score','away_score']],on='game_id',validate='many_to_one')
    q=q[(q.kickoff_utc+pd.Timedelta(hours=12)<=cutoff)&q.home_score.notna()&q.away_score.notna()]
    if q.empty:return None
    q=q.sort_values(['kickoff_utc','game_id','dropbacks','passer_player_id'],ascending=[False,False,False,True])
    return str(q.iloc[0].passer_player_id)

def options(game,team,evidence,auto,cutoff):
    d=evidence[evidence.game_id.eq(game)&evidence.team.eq(team)]
    result=[]
    if len(d):
        # The latest report supersedes any earlier claim of confirmation.
        latest=d.observed_at_utc.max()
        recent=d[d.observed_at_utc.eq(latest)]
        conf=recent[recent.status.eq('confirmed')]
        live=conf if len(conf) else recent
        for r in live.to_dict('records'):
            age=(cutoff-r['published_at_utc']).total_seconds()/3600
            label='CONFIRMED' if r['status']=='confirmed' and age<=MAX_REPORT_AGE_HOURS else ('STALE_REPORT' if age>MAX_REPORT_AGE_HOURS else 'UNCONFIRMED_'+r['status'].upper())
            result.append(dict(id=r['qb_id'],name=r['qb_name'],verification=label,source=r['source_url'],published=r['published_at_utc'].isoformat(),observed=r['observed_at_utc'].isoformat()))
    if not result and not auto.empty:
        rows=auto[auto.game_id.eq(game)&auto.team.eq(team)]
        if len(rows)>1:raise ValueError('Duplicate automatic QB candidate')
        if len(rows):
            t=rows.iloc[0]
            if pd.Timestamp(t.feature_cutoff_utc)>cutoff:raise ValueError('Future depth-chart capture')
            qid=str(t.get('qb_candidate_id','')).strip()
            if qid and qid.lower()!='nan':result.append(dict(id=qid,name=t.get('qb_candidate_name',''),verification='UNCONFIRMED_DEPTH_CHART',source='',published='',observed=str(t.feature_cutoff_utc)))
    return result or [dict(id='',name='',verification='MISSING',source='',published='',observed='')]

def scenarios(features,auto,evidence,qbs,games,cutoff,model,columns):
    from shadow_compare import qb_profile
    evidence=validate(evidence,cutoff,games)
    completed=games[games.home_score.notna()&games.away_score.notna()&(games.kickoff_utc+pd.Timedelta(hours=12)<=cutoff)]
    qbs=qbs[qbs.game_id.isin(completed.game_id)].copy()
    if qbs.duplicated(['game_id','posteam','passer_player_id']).any():raise ValueError('Duplicate QB game statistics')
    stats=qbs[['dropbacks','epa_sum','success_sum']].to_numpy(dtype=float)
    if not np.isfinite(stats).all() or (qbs.dropbacks<=0).any() or (qbs.success_sum<0).any() or (qbs.success_sum>qbs.dropbacks).any():raise ValueError('Invalid prior QB statistics')
    rows=[]
    for f in features.to_dict('records'):
        choices=[options(f['game_id'],f[side+'_team'],evidence,auto,cutoff) for side in ['home','away']]
        if len(choices[0])*len(choices[1])>16:raise ValueError('More than 16 QB scenarios for one game')
        refs={side:reference_qb(f[side+'_team'],qbs,games,cutoff) for side in ['home','away']}
        for home,away in product(*choices):
            r=dict(starter_strategy_version=VERSION,game_id=f['game_id'],home_team=f['home_team'],away_team=f['away_team'],forecast_cutoff_utc=cutoff.isoformat(),kickoff_utc=f['kickoff_utc'].isoformat(),baseline_predicted_margin=f['baseline_predicted_margin'],scenario_predicted_margin=np.nan,adjustment_points=np.nan,scenario_status='BLOCKED_MISSING_QB',both_starters_confirmed=home['verification']==away['verification']=='CONFIRMED')
            profiles=[]
            for side,opt in [('home',home),('away',away)]:
                r.update({side+'_qb_id':opt['id'],side+'_qb_name':opt['name'],side+'_verification':opt['verification'],side+'_source_url':opt['source'],side+'_source_published_at_utc':opt['published'],side+'_source_observed_at_utc':opt['observed'],side+'_reference_qb_id':refs[side],side+'_epa_vs_reference':np.nan})
                p=qb_profile(opt['id'],qbs,games,cutoff) if opt['id'] else None
                ref=qb_profile(refs[side],qbs,games,cutoff) if refs[side] else None
                profiles.append(p)
                if p and ref:r[side+'_epa_vs_reference']=p['epa']-ref['epa']
            if all(p is not None for p in profiles):
                if any(p['missing'] for p in profiles):r['scenario_status']='BLOCKED_NO_PRIOR_QB_SAMPLE'
                else:
                    x=pd.DataFrame([f]);h,a=profiles
                    for key in ['epa','success','dropbacks']:x['qb_'+key+'_diff']=h[key]-a[key]
                    x['home_qb_missing']=0.;x['away_qb_missing']=0.
                    pred=float(model.predict(x[columns])[0])
                    r.update(scenario_predicted_margin=pred,adjustment_points=pred-f['baseline_predicted_margin'],scenario_status='CONFIRMED_STARTER_CANDIDATE' if r['both_starters_confirmed'] else 'UNCONFIRMED_SCENARIO_ONLY')
            rows.append(r)
    return pd.DataFrame(rows,columns=SCHEMA)
