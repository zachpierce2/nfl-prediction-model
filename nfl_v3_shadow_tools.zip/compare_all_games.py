"""Compare first pre-kickoff venue forecasts on every game; no odds required."""
import argparse,json
from pathlib import Path
import pandas as pd
from shadow_compare import digest,raw_schedule

def compare(archive,schedule_path,cutoff):
    frames=[]
    for path in Path(archive).glob('data/shadow_predictions/*/all_game_forecasts.csv'):
        manifest=json.loads((path.parent/'manifest.json').read_text())
        if manifest.get('files',{}).get(path.name)!=digest(path):raise ValueError('Forecast checksum mismatch')
        f=pd.read_csv(path)
        if not f.empty:frames.append(f)
    if not frames:return pd.DataFrame()
    f=pd.concat(frames,ignore_index=True)
    f['forecast_cutoff_utc']=pd.to_datetime(f.forecast_cutoff_utc,utc=True)
    f['kickoff_utc']=pd.to_datetime(f.kickoff_utc,utc=True)
    f=f[f.forecast_cutoff_utc.lt(f.kickoff_utc)].sort_values('forecast_cutoff_utc').drop_duplicates('game_id')
    g=raw_schedule(schedule_path)[['game_id','kickoff_utc','home_score','away_score']]
    f=f.merge(g,on='game_id',suffixes=('_recorded','_actual'),validate='one_to_one')
    f=f[(f.kickoff_utc_recorded-f.kickoff_utc_actual).abs().le(pd.Timedelta(minutes=10))&f.kickoff_utc_actual.add(pd.Timedelta(hours=12)).le(pd.Timestamp(cutoff))&f.forecast_cutoff_utc.lt(f.kickoff_utc_actual)]
    f=f.dropna(subset=['home_score','away_score','baseline_predicted_margin','neutral_predicted_margin'])
    f['actual_margin']=f.home_score-f.away_score
    for name in ['baseline','neutral']:f[name+'_absolute_error']=(f[name+'_predicted_margin']-f.actual_margin).abs()
    return f

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--archive',required=True);p.add_argument('--schedule',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    f=compare(a.archive,a.schedule,pd.Timestamp.now(tz='UTC'));f.to_csv(a.out,index=False)
    print(json.dumps({'paired_games':len(f),'mae':{n:float(f[n+'_absolute_error'].mean()) for n in ['baseline','neutral']} if len(f) else {}}))
