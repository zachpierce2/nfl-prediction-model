import unittest
import tempfile
import json
from pathlib import Path
import numpy as np
import pandas as pd
from all_stats import aggregate, read_pbp, features, evaluate_archive, digest, VERSION, PBP_COLUMNS, COUNTS, EXTRA

def play(**kw):
    d=dict.fromkeys(PBP_COLUMNS,0)
    d.update(game_id='g1',posteam='A',defteam='B',play_type='pass',qb_dropback=1,down=1,yardline_100=60,fixed_drive=1)
    d.update(kw)
    return d

class AllStatsTests(unittest.TestCase):
    def test_numerators_denominators_and_nullified_plays(self):
        p=[play(yards_gained=20),play(yards_gained=19),play(sack=1,yards_gained=-5),
           play(play_type='run',qb_dropback=1,yards_gained=21),
           play(down=3,third_down_converted=1),play(down=3,third_down_failed=1),
           play(qb_kneel=1),play(qb_spike=1),play(play_type='no_play',yards_gained=60)]
        r=aggregate(pd.DataFrame(p)).iloc[0]
        self.assertEqual((r.explosive_plays,r.scrimmage_plays,r.sacks,r.dropbacks,r.third_conversions,r.third_attempts),(2,6,1,6,1,2))

    def test_red_zone_is_per_possession_and_not_defensive_touchdowns(self):
        p=[play(yardline_100=20),play(yardline_100=10),play(yardline_100=5,pass_touchdown=1),
           play(fixed_drive=2,yardline_100=15),play(fixed_drive=2,yardline_100=10),
           play(fixed_drive=3,yardline_100=60,pass_touchdown=1),
           play(fixed_drive=4,yardline_100=10,play_type='no_play')]
        r=aggregate(pd.DataFrame(p)).iloc[0]
        self.assertEqual((r.red_zone_tds,r.red_zone_trips),(1,2))

    def test_actual_parquet_read_without_no_play_column(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'fixture.parquet'
            pd.DataFrame([play(yards_gained=25),play(play_type='no_play',yards_gained=60)]).to_parquet(path,index=False)
            self.assertNotIn('no_play',pd.read_parquet(path).columns)
            row=aggregate(read_pbp(path)).iloc[0]
            self.assertEqual((row.scrimmage_plays,row.explosive_plays),(1,1))

    def test_parquet_missing_column_is_actionable(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'fixture.parquet'
            pd.DataFrame([play()]).drop(columns='sack').to_parquet(path,index=False)
            with self.assertRaisesRegex(ValueError,'missing required extended-stat fields.*sack'):
                read_pbp(path)

    def test_missing_schema_fails(self):
        with self.assertRaises(ValueError):aggregate(pd.DataFrame([play()]).drop(columns='sack'))

    def fixture(self):
        g=pd.DataFrame([dict(game_id='g1',home_team='A',away_team='B',gameday='2026-01-01',kickoff_utc='2026-01-01T18:00:00Z',home_score=10,away_score=7),dict(game_id='g2',home_team='A',away_team='B',gameday='2026-01-08',kickoff_utc='2026-01-08T18:00:00Z',home_score=np.nan,away_score=np.nan)])
        counts=pd.DataFrame([{'game_id':'g1','posteam':t,'defteam':o,**dict.fromkeys(COUNTS,0)} for t,o in [('A','B'),('B','A')]])
        counts['scrimmage_plays']=10
        counts.loc[counts.posteam.eq('A'),'explosive_plays']=2
        return g,counts

    def test_no_current_or_future_game_leakage(self):
        g,c=self.fixture();f=features(g,c,'2026-01-09T12:00:00Z').set_index('game_id')
        self.assertTrue(np.isnan(f.loc['g1','off_explosive_rate_diff']))
        self.assertAlmostEqual(f.loc['g2','off_explosive_rate_diff'],.2)
        self.assertAlmostEqual(f.loc['g2','def_explosive_rate_diff'],-.2)
        # Even if a future schedule has scores and supplied stats, it cannot update histories.
        g.loc[0,['home_score','away_score']]=[50,0]
        early=features(g,c,'2026-01-01T19:00:00Z').set_index('game_id')
        self.assertTrue(np.isnan(early.loc['g2','off_explosive_rate_diff']))

    def test_zero_opportunities_are_missing(self):
        g,c=self.fixture();f=features(g,c,'2026-01-09T12:00:00Z').set_index('game_id')
        self.assertTrue(np.isnan(f.loc['g2','home_off_red_zone_td_rate']))
        self.assertEqual(f.loc['g2','home_off_red_zone_td_rate_missing'],1)
        self.assertTrue(set(EXTRA).issubset(f.columns))

    def test_missing_coverage_fails(self):
        g,c=self.fixture()
        with self.assertRaises(ValueError):features(g,c.iloc[:1],'2026-01-09T12:00:00Z')

    def test_same_day_games_not_used(self):
        g,c=self.fixture();g.loc[1,'gameday']='2026-01-01'
        f=features(g,c,'2026-01-10T00:00:00Z').set_index('game_id')
        self.assertTrue(np.isnan(f.loc['g2','off_explosive_rate_diff']))

    def test_duplicate_stats_fail(self):
        g,c=self.fixture()
        with self.assertRaises(ValueError):features(g,pd.concat([c,c]),'2026-01-10T00:00:00Z')

    def test_rates_pool_opportunities_with_decay(self):
        g,c=self.fixture()
        g.loc[1,['home_score','away_score']]=[20,10]
        third=g.iloc[[1]].copy();third['game_id']='g3';third['gameday']='2026-01-15';third['kickoff_utc']='2026-01-15T18:00:00Z';third[['home_score','away_score']]=np.nan
        c2=c.copy();c2['game_id']='g2';c2['scrimmage_plays']=100;c2['explosive_plays']=0
        f=features(pd.concat([g,third]),pd.concat([c,c2]),'2026-01-16T12:00:00Z').set_index('game_id')
        self.assertAlmostEqual(f.loc['g3','home_off_explosive_rate'],1.7/108.5)

    def test_evaluate_first_snapshot_and_detect_tampering(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);out=root/'out';out.mkdir()
            p=root/'data/shadow_predictions/run';p.mkdir(parents=True)
            f=pd.DataFrame([dict(game_id='g1',home_team='A',away_team='B',kickoff_utc='2026-01-01T18:00:00Z',forecast_cutoff_utc='2026-01-01T09:00:00Z',prediction_created_at_utc='2026-01-01T10:00:00Z',baseline_predicted_margin=4,neutral_predicted_margin=4,all_stats_predicted_margin=3)])
            path=p/'all_stats_forecasts.csv';f.to_csv(path,index=False)
            (p/'manifest.json').write_text(json.dumps({'all_stats_candidate':{'version':VERSION},'files':{path.name:digest(path)}}))
            g,_=self.fixture();g['kickoff_utc']=pd.to_datetime(g.kickoff_utc,utc=True)
            s=evaluate_archive(root,g,pd.Timestamp('2026-01-10T00:00:00Z'),out)
            self.assertEqual(s['settled_games'],1);self.assertEqual(s['mae']['all_stats'],0)
            path.write_text(path.read_text()+'\n')
            with self.assertRaises(ValueError):evaluate_archive(root,g,pd.Timestamp('2026-01-10T00:00:00Z'),out)

if __name__=='__main__':unittest.main()
