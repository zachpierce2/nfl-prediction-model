# Starting-quarterback candidate

This update is built from your uploaded repository snapshot. It has not been installed on GitHub. Locked V3 remains the reference model; the new starter candidate uses that estimator and its training recipe, separately from the neutral-site candidate.

## New behavior

1. Read source-checked starter reports from nfl_data_inputs/qb_starters.csv. Validate team/game identity, HTTPS attribution, explicit timezones, publication before observation, observations before forecast and kickoff, and conflicting simultaneous confirmations.
2. Distinguish confirmed, expected, stale and depth-chart-only reports. Only reports explicitly entered as confirmed and published within 24 hours can create a confirmed starter candidate. A later expected report supersedes an earlier confirmation. Missing files leave starters unconfirmed.
3. Use each QB's last eight eligible prior games, with EPA shrunk toward zero by 100 prior dropbacks and success rate toward 50%. Replace only QB EPA/success/sample/missing features, and score with the existing locked model. The adjustment is the model's scenario prediction minus its original prediction; there is no invented point value or fitted-on-future coefficient.
4. Show the previous dominant team QB and each starter's EPA difference from that reference. A QB with no prior sample is blocked rather than assigned an unsupported adjustment.
5. Write qb_starter_scenarios.csv for every upcoming scheduled game in the seven-day horizon, even without market quotes. Uncertain alternatives produce separate rows without made-up scenario probabilities. Unconfirmed scenarios are excluded from the confirmed-candidate performance report.
6. Preserve starter_evidence.csv and both timestamped outputs in each checksummed run archive. Evaluate mode adds qb_starters_settled.csv and qb_starters_summary.json, comparing the first usable dual-confirmed pre-kickoff snapshot per game against V3 on exactly the same outcomes. There is no spread threshold.

The existing all_game_forecasts.csv still shows the original QB-status audit. Use qb_starter_scenarios.csv for the new source-attributed starter status and candidate margin.

## Evidence input

The included nfl_data_inputs/qb_starters.csv is intentionally empty except for its header. Enter these fields for a starter report you have checked:

| Column | Meaning |
| --- | --- |
| game_id | Exact schedule game ID |
| team | Schedule team code |
| qb_id | nflverse passer player ID |
| qb_name | Display name |
| status | confirmed, expected or scenario |
| source_url | HTTPS link to the checked report |
| published_at_utc | When the report was published, with Z or UTC offset |
| observed_at_utc | When the report was checked, with Z or UTC offset |

The code validates provenance fields and timing. It does not fetch the linked page or independently establish whether its claim is true. A depth chart alone must remain expected, never confirmed. For alternatives, enter multiple expected/scenario rows with the same observation timestamp. Re-check and append new evidence when status changes; do not fabricate a recent publication time to refresh an old report. This version requires source-checked input; automatic official starter-report collection is not implemented.

## Installation

Replace these two files together in your repository:

- nfl_v3_shadow_tools.zip
- .github/workflows/nfl-v3-shadow.yml

Also add nfl_data_inputs/qb_starters.csv if you want to supply starter evidence. Run NFL V3 Candidate Comparison in test mode first, then forecast. The updated workflow passes the evidence file automatically; an absent or empty file is safe and keeps inputs unconfirmed. Evaluate mode grades saved confirmed forecasts without requesting odds.

Local usage after extracting the inner ZIP:

    python -m pip install -r requirements.txt
    python verify.py
    python -m unittest discover -v
    python shadow_compare.py --data CAPTURE_DIRECTORY --archive ARCHIVE_DIRECTORY --out NEW_OUTPUT_DIRECTORY --qb-confirmations nfl_data_inputs/qb_starters.csv

## Validation and limits

39 automated tests pass, covering locked-reference replay, evidence timing and conflict rejection, stale and missing reports, future-stat exclusion, rookie blocking, backup-vs-reference math, uncertainty scenarios, one-result-per-game grading and archive tampering. An offline integration run also fit the actual locked estimator, built full historical features, consumed synthetic starter evidence, generated a scenario without sportsbook quotes and verified output checksums. Synthetic fixtures are not real NFL forecasts.

No fresh live starter sources were collected, no real-game starter-adjusted forecast was issued, and no new ATS win rate has been established. This is a prospective research candidate. The existing QB inputs were trained using prior observed starters; replacing them with announced starters changes their live distribution and must be evaluated before promotion. Injury and opponent-specific QB adjustments are not newly implemented by this update.
