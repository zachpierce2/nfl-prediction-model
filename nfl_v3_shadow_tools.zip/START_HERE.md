# V3 prospective candidate comparison

This adds a NEW workflow alongside the working automatic data collector. Your original model/workflows and the frozen historical benchmark remain unchanged.

## Install

1. Upload nfl_v3_shadow_tools.zip STILL ZIPPED to the main folder of the same GitHub repository.
2. Keep the existing nfl_advanced_data_auto.zip. The new workflow verifies its existing checksum and reuses that collector.
3. Create .github/workflows/nfl-v3-shadow.yml using the COMPLETE YAML provided in chat. Commit it to main.
4. Actions > NFL V3 Candidate Comparison > Run workflow > main > test. This checks installation and the frozen-reference replay, with no live odds request.
5. Start a NEW run on main in forecast mode. It uses your existing ODDS_API_KEY secret, makes one fresh odds request, captures source reports, predicts, and writes a comparison ledger to the existing nfl-data-archive branch. Do not use Re-run jobs on an old commit after installing updates.

Use this new forecast workflow when you want both collection and prediction; it performs the collection itself. You do not need to run the older capture workflow first. Both workflows share the same concurrency group to avoid archive push races. There is no recurring schedule. Use evaluate mode after games finish to refresh settlement WITHOUT an odds request or new predictions. It downloads the latest schedule/results and saves evaluation under data/shadow_evaluations/. You can also run forecast again to collect new games and update earlier results.

## Three arms, with distinct readiness

1. locked_v3: a newly versioned live extension of the locked EPA boosted-tree recipe. Same frozen 2017-2025 training features and original parameters; new games receive newly observed score/Elo and EPA histories. The previously saved benchmark files are not replaced.
2. qb_candidate: the same fitted regressor, with the prior-eight-game QB EPA, success and experience features replaced using the current depth-chart candidate's actual earlier-game history. An unconfirmed candidate is labeled as such. Missing history or uncertain candidate status blocks this arm; no zero rating or 100% starting probability is invented. The historical training QB features used last-observed QBs, so this prospective input change is an unvalidated distribution shift.
3. qb_injury_shadow: a Ridge residual model over the QB arm, using position-group observed-Out exposure differences, report coverage counts and missing-snap/uncertainty counts. It starts BLOCKED because no completed prospective injury observations exist. It automatically fits only once 200 unique eligible paired games with usable injury inputs have settled. Those observations must come from the archived pregame prediction ledger. No retrospective injury backfill or hand-written injury point adjustments are used. The fitted layer remains shadow research, not an approved strategy.

Current injury features are partial observed report exposure, not complete IR/reserve coverage, healthy usage or replacement quality. A lower bound of zero observed exposure does not mean a healthy team. Missing same-week report coverage blocks the injury arm for that game. The QB arm can still forecast.

## Fixed comparison protocol

- Strategy version: V3_SHADOW_QB_INJURY_V1.
- Training is frozen through the 2025 season. No 2026 outcome tuning of the base regressor.
- Book: DraftKings. No fallback to another book or retrospective line shopping.
- Two matched opposite-handicap quotes required; recorded quote age at forecast creation must be <=15 minutes. Automatic report snapshot must also be fresh.
- Decisions are eligible from 7 days to 1 hour before recorded kickoff.
- Selection rule fixed at absolute model edge >=3 points. Below the threshold is a pass. This is a margin rule, not estimated expected value.
- Common baseline/QB analysis uses the FIRST eligible snapshot per game with valid forecasts from BOTH arms. Repeated runs, later prices or later QB changes do not replace it. Baseline-only blocked-QB snapshots remain in the raw record but are not counted in the paired comparison.
- Settlement needs both scores and a conservative 12-hour kickoff buffer. Rescheduled kickoff disagreements are excluded for review; the code does not invent sportsbook void rules.
- Hypothetical returns use the recorded price for the selected side, risking 1 unit per selected game. Pushes return zero profit. No wager is placed and an API quote does not establish a fill.
- Current-season PBP, QB histories and score histories use only eligible earlier games. Future scores and current-game actual starter IDs do not enter prediction features.
- Old prediction ledgers are checksum-checked before reuse.

The three-point rule was previously inspected in historical research and is not independent evidence. The frozen 2020-2025 results remain exploratory. Future prospectively recorded results will supply the new evidence. There is no promised bet count, win percentage or profit.

## Outputs

Download the nfl-v3-shadow-... artifact. It contains fresh capture/availability/auto_reports folders plus comparison/:

- game_predictions.csv: home-team predicted winning margin for each arm, exact quote/prices, source/creation times, candidate IDs/names, availability flags, injury design and pass/home/away/blocked selections. Positive margin means home favored. Eligibility is a separate column; a direction on an ineligible row is not a counted selection.
- baseline_live_features.csv and qb_live_features.csv: inputs, so the QB substitution can be audited.
- reference_replay.json: checks the 2025 historical benchmark before any forecast.
- settled_first_observations.csv: paired first observations with known outcomes.
- comparison.csv: baseline/QB performance on their common settled cohort. The injury row may have fewer observations, shown explicitly.
- comparison_injury_common.csv: all three arms restricted to the SAME injury-forecast-available settled cohort.
- manifest.json: model version, source hashes, fixed protocol, parameter values, training provenance and injury-model readiness.
- live_team_stats.csv.gz/live_qb_stats.csv.gz: the observed current-season aggregates used to build histories. The very large raw parquet is not committed.

With zero settled games, accuracy/ROI/MAE fields are blank. That means pending evidence, not a zero-percent win rate. The initial injury_model status is WAITING_FOR_SETTLED_DATA. A green run does not mean it is trained or profitable. NO_FRESH_FORECASTS means quote/source timing blocked output; run a new forecast rather than recycling stale inputs.

Data and prediction snapshots are committed under the separate nfl-data-archive branch. Never merge that data branch into main. Artifacts expire after 90 days; branch history remains unless deleted. Existing archive branch and repository write permission are required; both were exercised by your earlier successful captures. The new workflow's live GitHub deployment has not been tested here. Evaluation mode also works without an available upcoming odds market.

## Validation

Eighteen automated tests cover historical-reference replay, QB-only substitution, absent/uncertain QB blocking, future information exclusion, missing injury coverage, unique first observations, prediction timing, rescheduling, exact-price returns, pushes/passes, the 200-game injury gate and archive integrity.

The 2025 EPA boosted-tree replay matched all 285 saved predictions with maximum absolute difference approximately 4.98e-11 points. Frozen training SHA256: 604bf569f3933bd1eaf8d3165b4fe14d810fa4cf3d77c87a8b360b37a8080f98.

A controlled-clock end-to-end replay of the uploaded capture produced 24 baseline and 20 QB forecasts, with 4 no-history QB blocks and zero settled games. That replay uses synthetic processing times and is NOT a live prediction ledger, a backtest win percentage, or prospective performance evidence. It is included only as a validation summary. No authenticated odds request, paid purchase, wager or new GitHub deployment was made during development.

Original model_v3.py/model_v3_epa.py and frozen feature bytes are copied unchanged. Historical PBP was fetched and aggregated to reconstruct earlier live histories; the aggregates and source hashes are bundled. These revised historical EPA values are not independently archived as-of estimates.

Attribution: nflverse/nflfastR contributors. Original package sources and limitations remain applicable.
- https://nflreadr.nflverse.com/reference/load_pbp.html
- https://github.com/nflverse/nflverse-data
- https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.HistGradientBoostingRegressor.html
