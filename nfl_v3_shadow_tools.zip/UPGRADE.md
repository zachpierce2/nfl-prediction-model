# Neutral-site and forecast-status candidate

This is a tested update built from the uploaded November 13 repository snapshot. Live GitHub access was unavailable; nothing has been installed or merged there.

## What changed

- Locked V3 remains the comparison model. Its archived training file and reference predictions are unchanged; its replay check still passes.
- The venue candidate sets home_field=0 and removes the 55-point Elo home bonus at neutral venues. It rebuilds historical training and current histories with this same rule. Unknown venue values fail explicitly.
- all_game_forecasts.csv includes every scheduled game in the next seven days in the active season, even without a matched sportsbook quote or QB candidate. It records locked V3 and neutral candidate margins, plus the separate QB candidate where available.
- The report labels QB starters UNCONFIRMED, reports partial/missing injury coverage and capture age, and compares actual PBP coverage with the latest completed scheduled game. A recently downloaded file alone does not mean its contents are current.
- The versioned research ledger avoids pooling this candidate's injury training with older strategy versions. Injury fitting remains gated at 200 eligible prospective settled games, and no injury deduction is invented.
- compare_all_games.py evaluates first pre-kickoff recorded baseline/neutral forecasts on a common set of settled games without a spread threshold or sportsbook quote requirement. Evaluate mode also writes all_games_settled.csv. The existing comparison.csv retains its original selected-bet research definition.

The neutral candidate and QB candidate are separate experiments. Starting-QB verification, full IR coverage and historically validated replacement-quality injury estimates remain future work. The all-game report's injury-adjustment field describes its baseline/neutral forecasts; the separate injury shadow margin remains in game_predictions.csv.

## Validation

28 automated checks passed, including exact locked 2025 replay, neutral Elo math, venue validation, pregame information boundaries, missing/stale status reporting and injury gates.

Offline 2020–2025 season walk-forward comparison on 1,693 games:

| Model | Mean absolute margin error |
| --- | ---: |
| Locked V3 | 10.4472 points |
| Neutral candidate | 10.4562 points |

The venue correction slightly worsened aggregate error in this experiment. It corrects venue semantics but is not evidence of a higher ATS win rate. Keep it as a candidate until prospective results support promotion. No current-week predictions or fresh live data were generated.

## Install

The outer delivery ZIP includes a replacement nfl_v3_shadow_tools.zip and .github/workflows/nfl-v3-shadow.yml with the updated bundle hash. Replace both files in your repository together. The advanced-data bundle is unchanged. Run NFL V3 Candidate Comparison in test mode first, then forecast mode to capture new reports. Evaluate mode grades saved forecasts without new odds.

For local use, extract nfl_v3_shadow_tools.zip, install requirements.txt, and run:

    python -m unittest discover -v
    python verify.py

The workflow preserves all_game_forecasts.csv alongside each prediction manifest. Only newly recorded V2 runs contain this report; older forecasts cannot be reconstructed as if they had been recorded before kickoff.
