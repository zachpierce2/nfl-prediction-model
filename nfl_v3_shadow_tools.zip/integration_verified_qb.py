import sys,tempfile,json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import pandas as pd,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import shadow_compare as s
from verified_qb import REQUIRED
class Clock:
    @classmethod
    def now(cls,tz=None):return pd.Timestamp('2026-11-13T08:00:00Z').to_pydatetime()
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp);data=root/'inputs';(data/'availability').mkdir(parents=True);(data/'auto_reports').mkdir()
    f=s.frozen_training('2026-11-13T00:00:00Z')
    cols=['game_id','season','week','gameday','gametime','home_team','away_team','home_score','away_score','location','home_qb_id','away_qb_id']
    games=f[cols].copy();games['gameday']=games.gameday.str[:10]
    games=pd.concat([games,pd.DataFrame([dict(game_id='2026_TEST_SF_SEA',season=2026,week=10,gameday='2026-11-15',gametime='16:00',home_team='SEA',away_team='SF',home_score=np.nan,away_score=np.nan,location='Home')])],ignore_index=True)
    games.to_csv(data/'availability/schedule.csv',index=False)
    q=pd.read_csv(s.ROOT/'historical_qb_stats.csv.gz');g=s.raw_schedule(data/'availability/schedule.csv')
    from verified_qb import reference_qb
    rows=[];e=[]
    for team in ['SF','SEA']:
        qid=reference_qb(team,q,g,s.utc('2026-11-13T08:00:00Z'))
        r=dict(game_id='2026_TEST_SF_SEA',team=team,feature_cutoff_utc='2026-11-13T07:59:00Z',qb_candidate_id=qid,qb_candidate_name='TEST',qb_candidate_status='depth_chart_only',injury_feed_status='missing',injury_players_reported=0,known_out_players_without_snap_history=0,unresolved_designations=0)
        r.update({'observed_out_snap_proxy_'+group:0 for group in s.GROUPS});rows.append(r)
        e.append(dict(game_id=r['game_id'],team=team,qb_id=qid,qb_name='TEST ONLY',status='confirmed',source_url='https://example.org/synthetic-fixture',published_at_utc='2026-11-13T07:00:00Z',observed_at_utc='2026-11-13T07:30:00Z'))
    pd.DataFrame(rows).to_csv(data/'auto_reports/team_features.csv',index=False)
    (data/'auto_reports/source_manifest.json').write_text(json.dumps({'feature_cutoff_utc':'2026-11-13T07:59:00Z'}))
    pd.DataFrame(columns=['sportsbook','game_id','side']).to_csv(data/'availability/matched_quotes.csv',index=False)
    evidence=root/'evidence.csv';pd.DataFrame(e).to_csv(evidence,index=False)
    t=pd.read_csv(s.ROOT/'historical_team_stats.csv.gz').iloc[:0];empty=q.iloc[:0]
    args=SimpleNamespace(out=root/'output',data=data,archive=root/'archive',pbp='synthetic-no-file',qb_confirmations=str(evidence))
    with patch.object(s,'datetime',Clock),patch.object(s,'load_live_pbp',return_value=(t,empty,{'synthetic':True})):
        s.run(args)
    out=pd.read_csv(root/'output/qb_starter_scenarios.csv')
    assert len(out)==1 and out.iloc[0].scenario_status=='CONFIRMED_STARTER_CANDIDATE'
    assert np.isfinite(out.iloc[0].scenario_predicted_margin)
    manifest=json.loads((root/'output/manifest.json').read_text())
    for name,sha in manifest['files'].items():assert s.digest(root/'output'/name)==sha
    assert len(pd.read_csv(root/'output/all_game_forecasts.csv'))==1
    assert len(pd.read_csv(root/'output/game_predictions.csv'))==0
    result={'status':'PASSED','fixture':'synthetic future game and confirmation sources; not a real NFL forecast','checks':['real locked-model fit','full historical feature construction','starter file consumption','confirmed scenario prediction','all-game forecast without market quotes','output manifest checksums'],'starter_scenarios':len(out)}
    (s.ROOT/'qb_integration_validation.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result))
