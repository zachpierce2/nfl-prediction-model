# All seven categories in the model

ALL_STATS_V1 trains a neutral-site candidate with the existing EPA/success/core features plus offensive and defensive explosive-play, sack, third-down conversion and red-zone TD rates. Outputs cover every scheduled game in the existing seven-day window, with no minimum spread difference.

The original locked model, neutral candidate, QB evidence and injury gates are retained. Automatic starter news collection was stopped and is not included.

Explosive means 20+ yards on a valid scrimmage play. Sack rate is sacks per dropback. Third-down rate uses recorded conversions/failures on valid scrimmage plays. Red-zone TD rate counts one possession with a pre-snap play at or inside the 20, and whether it scored an offensive TD. This definition may differ from the screenshot provider.

History uses the prior eight completed games, .85 decay on counts. Zero opportunities are missing, with flags; they are not treated as zero performance. Defensive rates describe rates allowed, except defensive sack rate describes sacks generated. Missing completed-game PBP coverage stops the run.

Installation: replace the repository-root nfl_v3_shadow_tools.zip with the accompanying inner ZIP, then replace .github/workflows/nfl-v3-shadow.yml with the accompanying YAML. Keep the current nfl_advanced_data_auto.zip and starter CSV. Run test mode, then forecast mode. The first forecast downloads 2017-2025 PBP and caches compact aggregates, before capturing fresh odds. Later runs reuse verified aggregates. Timeout is 60 minutes.

Files: all_stats_forecasts.csv includes the retrained forecast and all raw offensive/defensive rolling rates; all_game_forecasts.csv includes the new prediction too. all_stats_starter_scenarios.csv applies the existing verified-starter evidence rules to the expanded model. all_stats_backtest_by_season.csv and all_stats_backtest_predictions.csv compare the same neutral core with/without the new inputs, training prior seasons only. Evaluate mode adds all_stats_settled.csv and all_stats_evaluation.json for the first pregame forecast per game.

No accuracy improvement has yet been measured on real extended data. 2020-2025 backtests are exploratory and use revised PBP, not point-in-time archives. Local integration testing used synthetic extended counts with the actual estimator, schedule and frozen core; synthetic results are not NFL forecasts or performance evidence. Real aggregate downloads/backtests run in GitHub forecast mode.

Primary data dictionary: https://nflreadr.nflverse.com/articles/dictionary_pbp.html
