import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
for name,expected in json.loads((root/'checksums.json').read_text()).items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:
        raise SystemExit('Comparison bundle checksum mismatch: '+name)
print('Comparison bundle verified.')
