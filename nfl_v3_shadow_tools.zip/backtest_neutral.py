"""Offline season walk-forward venue experiment, using locked EPA features."""
import json
import pandas as pd
import model_v3 as base
from shadow_compare import frozen_training,regressor,COLUMNS
from threadpoolctl import threadpool_limits
f=frozen_training('2026-11-13T00:00:00Z')
f['gameday']=pd.to_datetime(f.gameday,utc=True)
fixed=base.make_features(f,neutral_sites=True).set_index('game_id')
c=f.copy().set_index('game_id')
for col in base.FEATURES:c[col]=fixed[col]
c=c.reset_index()
rows=[]
with threadpool_limits(limits=1):
    for season in range(2020,2026):
        for name,d in [('locked_v3',f),('neutral_candidate',c)]:
            tr=d[d.season.lt(season)];te=d[d.season.eq(season)]
            model=regressor().fit(tr[COLUMNS],tr.actual_margin)
            pred=model.predict(te[COLUMNS])
            rows.append(dict(season=season,model=name,games=len(te),mae=float(abs(pred-te.actual_margin).mean())))
pd.DataFrame(rows).to_csv('neutral_backtest.csv',index=False)
print(json.dumps(rows,indent=2))
