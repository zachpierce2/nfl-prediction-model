import unittest
import numpy as np
import pandas as pd
import model_v3 as base
from forecast_status import forecast_status

class VenueTests(unittest.TestCase):
    def games(self,location):
        return pd.DataFrame([dict(game_id='a',gameday=pd.Timestamp('2025-01-01',tz='UTC'),home_team='A',away_team='B',home_score=24,away_score=17,location=location),dict(game_id='b',gameday=pd.Timestamp('2025-01-08',tz='UTC'),home_team='A',away_team='B',home_score=np.nan,away_score=np.nan,location='Home')])
    def test_neutral_removes_home_feature_and_elo_bonus(self):
        corrected=base.make_features(self.games('Neutral'),neutral_sites=True)
        self.assertEqual(corrected.iloc[0].home_field,0)
        self.assertAlmostEqual(corrected.iloc[1].home_elo,1510)
        self.assertAlmostEqual(corrected.iloc[1].away_elo,1490)
    def test_home_and_legacy_unchanged(self):
        pd.testing.assert_frame_equal(base.make_features(self.games('Home')),base.make_features(self.games('Home'),neutral_sites=True))
        self.assertEqual(base.make_features(self.games('Neutral')).iloc[0].home_field,1)
    def test_unknown_venue_rejected(self):
        with self.assertRaises(ValueError):base.make_features(self.games(''),neutral_sites=True)
    def test_future_result_does_not_change_earlier_features(self):
        a=self.games('Neutral');b=a.copy();b.loc[1,'home_score']=99;b.loc[1,'away_score']=0
        pd.testing.assert_frame_equal(base.make_features(a,True)[base.FEATURES],base.make_features(b,True)[base.FEATURES])
    def test_status_missing_and_stale_coverage(self):
        f=pd.DataFrame([dict(game_id='future',home_team='A',away_team='B',candidate_home_field=0)])
        games=self.games('Home');games['kickoff_utc']=games.gameday;games.loc[1,['home_score','away_score']]=[20,10]
        teams=pd.DataFrame([dict(game_id='a',posteam='A')])
        auto=pd.DataFrame(columns=['game_id','team'])
        r=forecast_status(f,auto,games,teams,pd.Timestamp('2025-01-10',tz='UTC')).iloc[0]
        self.assertEqual(r.home_pbp_coverage_status,'BEHIND_COMPLETED_SCHEDULE')
        self.assertEqual(r.away_pbp_coverage_status,'MISSING')
        self.assertEqual(r.home_qb_confirmation,'UNCONFIRMED')
        self.assertFalse(r.injury_adjustment_applied)

class AllGameTests(unittest.TestCase):
    def test_all_game_grade_has_no_market_requirement(self):
        import tempfile,json
        from pathlib import Path
        from shadow_compare import digest
        from compare_all_games import compare
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);folder=root/'data/shadow_predictions/run';folder.mkdir(parents=True)
            path=folder/'all_game_forecasts.csv'
            pd.DataFrame([dict(game_id='g',forecast_cutoff_utc='2026-01-01T00:00:00Z',kickoff_utc='2026-01-02T18:00:00Z',baseline_predicted_margin=1,neutral_predicted_margin=2)]).to_csv(path,index=False)
            (folder/'manifest.json').write_text(json.dumps({'files':{path.name:digest(path)}}))
            schedule=root/'schedule.csv'
            pd.DataFrame([dict(game_id='g',season=2025,week=18,gameday='2026-01-02',gametime='13:00',home_team='A',away_team='B',home_score=20,away_score=17)]).to_csv(schedule,index=False)
            f=compare(root,schedule,pd.Timestamp('2026-01-04',tz='UTC'))
            self.assertEqual(len(f),1)
            self.assertEqual(f.iloc[0].neutral_absolute_error,1)
            path.write_text('tampered')
            with self.assertRaises(ValueError):compare(root,schedule,pd.Timestamp('2026-01-04',tz='UTC'))

if __name__=='__main__':unittest.main()
