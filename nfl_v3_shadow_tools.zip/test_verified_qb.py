import unittest,tempfile,json
from pathlib import Path
import numpy as np
import pandas as pd
from verified_qb import scenarios,validate,REQUIRED
from shadow_compare import digest
from compare_verified_qb import compare

class ToyModel:
    def predict(self,x):return x.qb_epa_diff.to_numpy()*20

class StarterTests(unittest.TestCase):
    def setUp(self):
        self.cutoff=pd.Timestamp('2026-11-13T08:00:00Z')
        self.games=pd.DataFrame([dict(game_id='old',kickoff_utc=pd.Timestamp('2026-11-08T21:00:00Z'),home_team='SF',away_team='SEA',home_score=24.,away_score=20.),dict(game_id='next',kickoff_utc=pd.Timestamp('2026-11-15T21:00:00Z'),home_team='SF',away_team='SEA',home_score=np.nan,away_score=np.nan)])
        self.qbs=pd.DataFrame([dict(game_id='old',posteam=t,passer_player_id=q,dropbacks=n,epa_sum=e,success_sum=n/2) for t,q,n,e in [('SF','h',100,20),('SF','backup',10,-5),('SEA','a',100,0)]])
        self.f=pd.DataFrame([dict(game_id='next',home_team='SF',away_team='SEA',kickoff_utc=self.games.iloc[1].kickoff_utc,baseline_predicted_margin=2.,qb_epa_diff=.1,qb_success_diff=0.,qb_dropbacks_diff=0.,home_qb_missing=0.,away_qb_missing=0.,elo_diff=99)])
        self.auto=pd.DataFrame([dict(game_id='next',team=t,qb_candidate_id=q,qb_candidate_name=q,feature_cutoff_utc=self.cutoff.isoformat()) for t,q in [('SF','h'),('SEA','a')]])
        self.e=pd.DataFrame([dict(game_id='next',team=t,qb_id=q,qb_name=q,status='confirmed',source_url='https://example.org/team-statement',published_at_utc='2026-11-13T07:00:00Z',observed_at_utc='2026-11-13T07:30:00Z') for t,q in [('SF','backup'),('SEA','a')]])
    def run_scenario(self,e=None,q=None):
        return scenarios(self.f,self.auto,self.e if e is None else e,self.qbs if q is None else q,self.games,self.cutoff,ToyModel(),['qb_epa_diff'])
    def test_confirmed_backup_is_relative_to_previous_dominant_qb(self):
        r=self.run_scenario().iloc[0]
        self.assertEqual(r.home_reference_qb_id,'h')
        self.assertAlmostEqual(r.home_epa_vs_reference,-5/110-.1)
        self.assertAlmostEqual(r.adjustment_points,-5/110*20-2)
        self.assertTrue(r.both_starters_confirmed)
        self.assertEqual(r.scenario_status,'CONFIRMED_STARTER_CANDIDATE')
    def test_depth_chart_never_confirmed(self):
        r=self.run_scenario(pd.DataFrame(columns=REQUIRED)).iloc[0]
        self.assertFalse(r.both_starters_confirmed)
        self.assertEqual(r.scenario_status,'UNCONFIRMED_SCENARIO_ONLY')
        self.assertAlmostEqual(r.adjustment_points,0)
    def test_ambiguous_reports_produce_separate_scenarios(self):
        e=self.e.copy();e['status']='expected';extra=e.iloc[[0]].copy();extra['qb_id']='h'
        r=self.run_scenario(pd.concat([e,extra],ignore_index=True))
        self.assertEqual(len(r),2);self.assertFalse(r.both_starters_confirmed.any())
    def test_stale_confirmation_is_unconfirmed(self):
        e=self.e.copy();e['published_at_utc']='2026-11-11T07:00:00Z'
        r=self.run_scenario(e).iloc[0];self.assertFalse(r.both_starters_confirmed)
        self.assertEqual(r.home_verification,'STALE_REPORT')
    def test_later_expected_report_supersedes_confirmation(self):
        extra=self.e.iloc[[0]].copy();extra['status']='expected';extra['observed_at_utc']='2026-11-13T07:45:00Z'
        self.assertFalse(self.run_scenario(pd.concat([self.e,extra])).iloc[0].both_starters_confirmed)
    def test_future_or_naive_report_rejected(self):
        for value in ['2026-11-14T07:00:00Z','2026-11-13T07:00:00']:
            e=self.e.copy();e.loc[0,'observed_at_utc']=value
            with self.assertRaises(ValueError):self.run_scenario(e)
    def test_conflicting_simultaneous_confirmations_rejected(self):
        extra=self.e.iloc[[0]].copy();extra['qb_id']='h'
        with self.assertRaises(ValueError):self.run_scenario(pd.concat([self.e,extra]))
    def test_missing_sample_blocks_instead_of_inventing_adjustment(self):
        e=self.e.copy();e.loc[0,'qb_id']='rookie'
        r=self.run_scenario(e).iloc[0];self.assertEqual(r.scenario_status,'BLOCKED_NO_PRIOR_QB_SAMPLE');self.assertTrue(pd.isna(r.adjustment_points))
    def test_future_qb_stats_do_not_change_forecast(self):
        q=self.qbs.copy();extra=q.iloc[[0]].copy();extra['game_id']='next';extra['epa_sum']=9999
        pd.testing.assert_frame_equal(self.run_scenario(),self.run_scenario(q=pd.concat([q,extra])))
    def test_wrong_team_and_invalid_source_rejected(self):
        for col,value in [('team','NYJ'),('source_url','file:///tmp/evidence')]:
            e=self.e.copy();e.loc[0,col]=value
            with self.assertRaises(ValueError):self.run_scenario(e)
    def test_archive_grades_confirmed_only_once_on_common_games(self):
        f=self.run_scenario();games=self.games.copy();games.loc[1,['home_score','away_score']]=[20,17]
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for name in ['a','b']:
                folder=root/'data/shadow_predictions'/name;folder.mkdir(parents=True)
                path=folder/'qb_starter_scenarios.csv';f.to_csv(path,index=False)
                (folder/'manifest.json').write_text(json.dumps({'files':{path.name:digest(path)}}))
            r=compare(root,games,pd.Timestamp('2026-11-17',tz='UTC'))
            self.assertEqual(len(r),1);self.assertAlmostEqual(r.iloc[0].baseline_absolute_error,1)
            self.assertTrue(compare(root,games,self.cutoff).empty)

if __name__=='__main__':unittest.main()
