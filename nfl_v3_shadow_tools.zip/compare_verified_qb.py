"""Grade first usable, dual-confirmed starter forecast per game on common outcomes."""
import argparse,json
from pathlib import Path
import pandas as pd
from shadow_compare import digest,raw_schedule
from verified_qb import VERSION

def compare(archive,games,cutoff):
    frames=[]
    for path in Path(archive).glob('data/shadow_predictions/*/qb_starter_scenarios.csv'):
        m=json.loads((path.parent/'manifest.json').read_text())
        if m.get('files',{}).get(path.name)!=digest(path):raise ValueError('Starter scenario checksum mismatch')
        f=pd.read_csv(path)
        if len(f):frames.append(f)
    if not frames:return pd.DataFrame()
    f=pd.concat(frames,ignore_index=True)
    for col in ['forecast_cutoff_utc','kickoff_utc']:f[col]=pd.to_datetime(f[col],utc=True,errors='raise')
    f=f[f.starter_strategy_version.eq(VERSION)&f.scenario_status.eq('CONFIRMED_STARTER_CANDIDATE')&f.home_verification.eq('CONFIRMED')&f.away_verification.eq('CONFIRMED')&f.forecast_cutoff_utc.lt(f.kickoff_utc)]
    f=f.dropna(subset=['scenario_predicted_margin','baseline_predicted_margin'])
    # Choose without consulting outcomes; each game counts once.
    f=f.sort_values(['forecast_cutoff_utc','game_id']).drop_duplicates('game_id')
    g=games[['game_id','kickoff_utc','home_score','away_score']]
    f=f.merge(g,on='game_id',suffixes=('_recorded','_actual'),validate='one_to_one')
    f=f[f.kickoff_utc_actual.add(pd.Timedelta(hours=12)).le(cutoff)&f.forecast_cutoff_utc.lt(f.kickoff_utc_actual)&(f.kickoff_utc_recorded-f.kickoff_utc_actual).abs().le(pd.Timedelta(minutes=10))].dropna(subset=['home_score','away_score'])
    f['actual_margin']=f.home_score-f.away_score
    for n,c in [('baseline','baseline_predicted_margin'),('starter','scenario_predicted_margin')]:f[n+'_absolute_error']=(f[c]-f.actual_margin).abs()
    return f

def summary(f):
    return dict(paired_settled_games=len(f),mae={n:float(f[n+'_absolute_error'].mean()) for n in ['baseline','starter']} if len(f) else {},status='RESEARCH_ONLY_NO_PROVEN_IMPROVEMENT',selection='first valid dual-confirmed pre-kickoff snapshot per game; every eligible game; no market threshold')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--archive',required=True);p.add_argument('--schedule',required=True);p.add_argument('--out',required=True);a=p.parse_args()
    f=compare(a.archive,raw_schedule(a.schedule),pd.Timestamp.now(tz='UTC'));f.to_csv(a.out,index=False);print(json.dumps(summary(f),indent=2))
