import tempfile,unittest,json
from pathlib import Path
import pandas as pd
import numpy as np
import shadow_compare as s

class ShadowTests(unittest.TestCase):
    def setUp(self):
        self.cutoff=s.utc('2026-11-13T08:00:00Z')
        self.games=pd.DataFrame([dict(game_id='old',season=2026,week=9,gameday='2026-11-08',home_team='SF',away_team='SEA',kickoff_utc=s.utc('2026-11-08T21:00:00Z'),home_score=24.,away_score=20.),dict(game_id='next',season=2026,week=10,gameday='2026-11-15',home_team='SF',away_team='SEA',kickoff_utc=s.utc('2026-11-15T21:00:00Z'),home_score=np.nan,away_score=np.nan)])
    def forecast(self,**kwargs):
        r=dict(strategy_version=s.VERSION,snapshot_id='a',game_id='old',prediction_created_at_utc='2026-11-07T21:00:00Z',kickoff_utc='2026-11-08T21:00:00Z',decision_eligible=True,baseline_predicted_margin=7.,qb_predicted_margin=0.,injury_predicted_margin=np.nan,injury_features_ready=True,home_line=-3.,home_odds_american=-120.,away_odds_american=105.)
        r.update({k:0. for k in s.INJURY_COLUMNS});r.update(kwargs);return r
    def test_historical_reference_matches(self):
        replay=s.verify_reference();self.assertEqual(replay['games'],285);self.assertLess(replay['max_abs_margin_difference'],1e-6)
    def test_qb_profile_no_future_leakage(self):
        q=pd.DataFrame([dict(game_id='old',passer_player_id='qb',dropbacks=100,epa_sum=20.,success_sum=50.),dict(game_id='next',passer_player_id='qb',dropbacks=100,epa_sum=1000.,success_sum=100.)])
        p=s.qb_profile('qb',q,self.games,self.cutoff)
        self.assertAlmostEqual(p['epa'],.1);self.assertEqual(p['dropbacks'],100)
    def auto(self):
        rows=[]
        for team,qb in [('SF','h'),('SEA','a')]:
            r=dict(game_id='next',team=team,feature_cutoff_utc='2026-11-13T07:50:00Z',qb_candidate_status='depth_chart_only',qb_candidate_id=qb,qb_candidate_name=qb,injury_feed_status='observed_partial',injury_players_reported=5,known_out_players_without_snap_history=0,unresolved_designations=0)
            r.update({'observed_out_snap_proxy_'+g:0. for g in s.GROUPS});rows.append(r)
        return pd.DataFrame(rows)
    def test_qb_override_changes_only_qb_fields(self):
        f=pd.DataFrame([dict(game_id='next',home_team='SF',away_team='SEA',qb_epa_diff=99.,qb_success_diff=99.,qb_dropbacks_diff=99.,home_qb_missing=1.,away_qb_missing=1.,elo_diff=10.)])
        q=pd.DataFrame([dict(game_id='old',passer_player_id='h',dropbacks=100,epa_sum=20.,success_sum=60.),dict(game_id='old',passer_player_id='a',dropbacks=100,epa_sum=0.,success_sum=40.)])
        result,status=s.qb_override(f,self.auto(),q,self.games,self.cutoff)
        self.assertAlmostEqual(result.iloc[0].qb_epa_diff,.1);self.assertEqual(result.iloc[0].elo_diff,10.);self.assertEqual(f.iloc[0].qb_epa_diff,99.)
        self.assertEqual(status.iloc[0].qb_candidate_status,'ready_depth_chart_only')
    def test_missing_qb_history_blocks(self):
        f=pd.DataFrame([dict(game_id='next',home_team='SF',away_team='SEA')]);q=pd.DataFrame(columns=['game_id','passer_player_id','dropbacks','epa_sum','success_sum'])
        _,status=s.qb_override(f,self.auto(),q,self.games,self.cutoff)
        self.assertEqual(status.iloc[0].qb_candidate_status,'candidate_qb_has_no_prior_sample')
    def test_uncertain_qb_blocks(self):
        auto=self.auto();auto.loc[0,'qb_candidate_status']='uncertain_injury'
        f=pd.DataFrame([dict(game_id='next',home_team='SF',away_team='SEA')]);q=pd.DataFrame(columns=['game_id','passer_player_id','dropbacks','epa_sum','success_sum'])
        _,status=s.qb_override(f,auto,q,self.games,self.cutoff)
        self.assertEqual(status.iloc[0].qb_candidate_status,'uncertain_or_missing_qb_candidate')
    def test_future_reports_rejected(self):
        auto=self.auto();auto.loc[0,'feature_cutoff_utc']='2026-11-14T00:00:00Z'
        f=pd.DataFrame([dict(game_id='next',home_team='SF',away_team='SEA')]);q=pd.DataFrame()
        with self.assertRaises(ValueError):s.qb_override(f,auto,q,self.games,self.cutoff)
    def test_injury_missing_never_zero_filled(self):
        auto=self.auto();auto.loc[0,'injury_feed_status']='missing'
        self.assertIsNone(s.injury_design(auto,'next','SF','SEA'))
    def test_injury_complete_design(self):
        auto=self.auto();auto.loc[0,'observed_out_snap_proxy_OL']=.8
        self.assertAlmostEqual(s.injury_design(auto,'next','SF','SEA')['inj_OL_diff'],.8)
    def test_first_paired_forecast_only(self):
        rows=[self.forecast(snapshot_id='later',prediction_created_at_utc='2026-11-08T15:00:00Z',qb_predicted_margin=20.),self.forecast()]
        first=s.first_observations(pd.DataFrame(rows));self.assertEqual(len(first),1);self.assertEqual(first.iloc[0].snapshot_id,'a')
    def test_ineligible_or_missing_candidate_not_counted(self):
        f=pd.DataFrame([self.forecast(decision_eligible=False),self.forecast(qb_predicted_margin=np.nan)])
        self.assertTrue(s.first_observations(f).empty)
    def test_no_postgame_predictions_or_early_scores(self):
        h=pd.DataFrame([self.forecast(prediction_created_at_utc='2026-11-08T22:00:00Z')])
        self.assertTrue(s.settle(h,self.games,self.cutoff).empty)
        self.assertTrue(s.settle(pd.DataFrame([self.forecast()]),self.games,s.utc('2026-11-09T01:00:00Z')).empty)
    def test_rescheduled_game_not_assumed_settled(self):
        h=pd.DataFrame([self.forecast(kickoff_utc='2026-11-08T18:00:00Z')]);self.assertTrue(s.settle(h,self.games,self.cutoff).empty)
    def test_actual_prices_used_in_returns(self):
        f=s.settle(pd.DataFrame([self.forecast()]),self.games,self.cutoff);r=s.comparison(f).set_index('model')
        self.assertEqual(r.loc['locked_v3','wins'],1);self.assertAlmostEqual(r.loc['locked_v3','hypothetical_profit_per_unit_risked'],100/120)
        self.assertEqual(r.loc['qb_candidate','losses'],1);self.assertEqual(r.loc['qb_candidate','hypothetical_profit_per_unit_risked'],-1)
    def test_push_and_pass(self):
        self.assertEqual(s.choice(5,-3),'pass');self.assertEqual(s.choice(float('nan'),-3),'blocked')
        r=self.forecast(home_line=-4.,qb_predicted_margin=8.);f=s.settle(pd.DataFrame([r]),self.games,self.cutoff)
        result=s.comparison(f).set_index('model');self.assertEqual(result.loc['locked_v3','pushes'],1)
    def test_no_fake_initial_injury_coefficients(self):
        model,info=s.fit_injury(pd.DataFrame());self.assertIsNone(model);self.assertEqual(info['eligible_training_games'],0)
    def test_injury_gate_and_unique_game_training(self):
        rows=[self.forecast(game_id=str(i),actual_margin=4.) for i in range(199)]
        model,info=s.fit_injury(pd.DataFrame(rows));self.assertIsNone(model)
        rows.append(self.forecast(game_id='199',actual_margin=4.));model,info=s.fit_injury(pd.DataFrame(rows));self.assertIsNotNone(model)
        self.assertEqual(info['status'],'SHADOW_ONLY_NOT_VALIDATED')
        rows.append(rows[0]);
        with self.assertRaises(ValueError):s.fit_injury(pd.DataFrame(rows))
    def test_archive_checksum_verification(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td)/'data/shadow_predictions/test';folder.mkdir(parents=True)
            p=folder/'game_predictions.csv';pd.DataFrame([self.forecast()]).to_csv(p,index=False)
            (folder/'manifest.json').write_text(json.dumps({'files':{'game_predictions.csv':s.digest(p)}}))
            self.assertEqual(len(s.load_history(td)),1)
            p.write_text('tampered')
            with self.assertRaises(ValueError):s.load_history(td)
    def test_evaluate_without_odds_or_new_predictions(self):
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);folder=root/'archive/data/shadow_predictions/test';folder.mkdir(parents=True)
            p=folder/'game_predictions.csv';pd.DataFrame([self.forecast()]).to_csv(p,index=False)
            (folder/'manifest.json').write_text(json.dumps({'files':{'game_predictions.csv':s.digest(p)}}))
            games=self.games.copy();games['gametime']='16:00';sp=root/'games.csv';games.to_csv(sp,index=False)
            s.evaluate(SimpleNamespace(archive=root/'archive',out=root/'evaluation',schedule=sp))
            m=json.loads((root/'evaluation/manifest.json').read_text())
            self.assertEqual(m['odds_requests'],0);self.assertEqual(m['paired_settled_games'],1)
            self.assertFalse((root/'evaluation/game_predictions.csv').exists())

if __name__=='__main__':unittest.main()
