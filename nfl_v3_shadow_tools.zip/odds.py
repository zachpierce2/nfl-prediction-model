"""Manual odds recording. No wagers or automatic historical purchases."""
import argparse,hashlib,json,os,sys,math
from datetime import datetime,timezone
from pathlib import Path
import urllib.parse,urllib.request,urllib.error
import pandas as pd
NAMES=['Arizona Cardinals','Atlanta Falcons','Baltimore Ravens','Buffalo Bills','Carolina Panthers','Chicago Bears','Cincinnati Bengals','Cleveland Browns','Dallas Cowboys','Denver Broncos','Detroit Lions','Green Bay Packers','Houston Texans','Indianapolis Colts','Jacksonville Jaguars','Kansas City Chiefs','Las Vegas Raiders','Los Angeles Chargers','Los Angeles Rams','Miami Dolphins','Minnesota Vikings','New England Patriots','New Orleans Saints','New York Giants','New York Jets','Philadelphia Eagles','Pittsburgh Steelers','San Francisco 49ers','Seattle Seahawks','Tampa Bay Buccaneers','Tennessee Titans','Washington Commanders']
TEAMS=dict(zip(NAMES,'ARI ATL BAL BUF CAR CHI CIN CLE DAL DEN DET GB HOU IND JAX KC LV LAC LAR MIA MIN NE NO NYG NYJ PHI PIT SF SEA TB TEN WAS'.split()))
COLS='event_id kickoff_utc home_team away_team captured_at_utc quote_updated_at_utc sportsbook side line odds_american quoted_home_margin quote_age_minutes provenance'.split()
def utc(s):
 t=pd.Timestamp(s)
 if t.tzinfo is None:raise ValueError('Timezone required')
 return t.tz_convert('UTC')
def normalize(events,captured,max_age_minutes=15):
 cutoff=utc(captured);rows=[];rejected=[]
 for e in events:
  try:kickoff=utc(e['commence_time']);home,away=TEAMS[e['home_team']],TEAMS[e['away_team']]
  except (KeyError,ValueError):rejected.append({'event_id':e.get('id'),'reason':'unknown_team_or_kickoff'});continue
  if kickoff<=cutoff:rejected.append({'event_id':e['id'],'reason':'already_started'});continue
  for book in e.get('bookmakers',[]):
   for m in book.get('markets',[]):
    if m.get('key')!='spreads':continue
    try:
     updated=utc(m.get('last_update') or book['last_update']);age=(cutoff-updated).total_seconds()/60
     if age<0 or age>max_age_minutes:raise ValueError('stale_or_future_quote')
     outcomes={x['name']:x for x in m['outcomes']};h,a=outcomes[e['home_team']],outcomes[e['away_team']]
     hp,ap=float(h['point']),float(a['point'])
     if not all(math.isfinite(x) for x in [hp,ap]) or any((x*2)%1 for x in [hp,ap]):raise ValueError('invalid_handicap')
     if abs(hp+ap)>1e-8:raise ValueError('mismatched_handicaps')
     prices=[float(h['price']),float(a['price'])]
     if any(not math.isfinite(x) or abs(x)<100 or not x.is_integer() for x in prices):raise ValueError('invalid_american_price')
     for side,item,price in [('home',h,prices[0]),('away',a,prices[1])]:
      rows.append(dict(event_id=e['id'],kickoff_utc=kickoff.isoformat(),home_team=home,away_team=away,captured_at_utc=cutoff.isoformat(),quote_updated_at_utc=updated.isoformat(),sportsbook=book['key'],side=side,line=float(item['point']),odds_american=int(price),quoted_home_margin=-hp,quote_age_minutes=round(age,3),provenance='provider_snapshot_not_verified_fill'))
    except (KeyError,ValueError,TypeError) as exc:rejected.append({'event_id':e['id'],'sportsbook':book.get('key'),'reason':str(exc)})
 return pd.DataFrame(rows,columns=COLS),rejected

def collect(out):
 key=os.environ.get('ODDS_API_KEY','').strip()
 if not key:raise ValueError('Add ODDS_API_KEY as a GitHub Actions repository secret; never paste it in chat or code.')
 query=urllib.parse.urlencode(dict(apiKey=key,regions='us',markets='spreads',oddsFormat='american',dateFormat='iso'))
 try:
  with urllib.request.urlopen('https://api.the-odds-api.com/v4/sports/americanfootball_nfl/odds?'+query,timeout=40) as r:
   raw=r.read();quota={k:r.headers.get(k) for k in ['x-requests-remaining','x-requests-used','x-requests-last']}
 except urllib.error.HTTPError as e:raise RuntimeError(f'Odds provider HTTP {e.code}. Check key/account/quota. URL omitted to protect the key.') from None
 except Exception:raise RuntimeError('Odds request failed. URL omitted to protect the key.') from None
 captured=datetime.now(timezone.utc).isoformat();events=json.loads(raw)
 if not isinstance(events,list):raise ValueError('Unexpected provider response')
 p=Path(out);p.mkdir(parents=True,exist_ok=False)
 quotes,rejected=normalize(events,captured)
 (p/'provider_response.json').write_bytes(raw);quotes.to_csv(p/'quotes.csv',index=False)
 (p/'rejected_quotes.json').write_text(json.dumps(rejected,indent=2))
 (p/'capture.json').write_text(json.dumps(dict(provider='The Odds API',captured_at_utc=captured,response_sha256=hashlib.sha256(raw).hexdigest(),quota=quota,accepted_quotes=len(quotes),note='Timestamped provider snapshot, not guaranteed executable odds or a wager fill.'),indent=2))
 print(f'Recorded {len(quotes)} pregame quotes; rejected {len(rejected)} records.')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);a=ap.parse_args()
 try:collect(a.out)
 except Exception as e:print(str(e),file=sys.stderr);sys.exit(1)
