#!/usr/bin/env python3
"""Repeatable exploratory comparison from a frozen pregame feature ledger."""
import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[name]='1'
import argparse
import hashlib
import importlib.metadata
import json
import platform
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits, threadpool_info
import model_v3 as baseline
from model_v3_epa import EXTRA, spread_report

ROOT=Path(__file__).resolve().parent

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def verify():
    lock=json.loads((ROOT/'lock.json').read_text())
    if platform.python_version()!=lock['python_version']:
        raise RuntimeError(f"Use Python {lock['python_version']}; got {platform.python_version()}")
    for name,version in lock['dependencies'].items():
        got=importlib.metadata.version(name)
        if got!=version: raise RuntimeError(f'{name}: expected {version}, got {got}')
    for relative,expected in lock['files'].items():
        if sha(ROOT/relative)!=expected:
            raise RuntimeError(f'Frozen input/code changed: {relative}')
    return lock

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',default='results'); args=ap.parse_args()
    lock=verify()
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    data=pd.read_csv(ROOT/'inputs/pregame_features.csv',float_precision='round_trip')
    basic=[x for x in baseline.FEATURES if x not in ['qb_margin_diff','qb_experience_diff']]
    scores=[]; predictions=[]
    with threadpool_limits(limits=1):
        for season in range(2020,2026):
            train=data[data.season<season]; test=data[data.season==season]
            for arm,features in [('baseline',basic),('epa',basic+EXTRA)]:
                models={
                    'ridge':make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),Ridge(alpha=100)),
                    'boosted_trees':make_pipeline(SimpleImputer(strategy='median'),HistGradientBoostingRegressor(max_iter=150,max_leaf_nodes=15,l2_regularization=10,learning_rate=.04,random_state=42))}
                for kind,model in models.items():
                    name=arm+'_'+kind
                    model.fit(train[features],train.actual_margin)
                    pred=model.predict(test[features])
                    mae=float(np.mean(abs(pred-test.actual_margin)))
                    scores.append(dict(season=season,model=name,games=len(test),mae=mae))
                    frame=test[['game_id','season','week','home_team','away_team','actual_margin','spread_line']].copy()
                    frame['predicted_margin']=pred; frame['model']=name; predictions.append(frame)
                    print(f'{season} {name}: {mae:.6f}',flush=True)
    predictions=pd.concat(predictions,ignore_index=True)
    predictions.to_csv(out/'predictions.csv',index=False,float_format='%.10f')
    pd.DataFrame(scores).to_csv(out/'by_season.csv',index=False,float_format='%.10f')
    spread_report(predictions).to_csv(out/'spread_backtest.csv',index=False)
    overall={name:round(float(np.mean(abs(g.predicted_margin-g.actual_margin))),10) for name,g in predictions.groupby('model')}
    summary={'model_mae':overall,'method':'Same fixed chronological season splits, models and threshold grid; frozen features rounded to 10 decimals.',
             'limitations':json.loads((ROOT/'inputs/source_summary.json').read_text())['limitations'],
             'not_a_live_model':'Frozen 2017-2025 research ledger; new games require a separately versioned data snapshot.',
             'baseline_change':'Starter-ID features removed in both arms, as in the preceding EPA comparison.'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    output_hashes={n:sha(out/n) for n in ['predictions.csv','by_season.csv','spread_backtest.csv','summary.json']}
    reference_path=ROOT/'expected_results.json'
    matches=None
    if reference_path.exists():
        expected=json.loads(reference_path.read_text())
        matches={n:output_hashes[n]==v for n,v in expected.items()}
    audit={'lock_sha256':sha(ROOT/'lock.json'),'python':sys.version,'platform':platform.platform(),
           'dependencies':lock['dependencies'],'input_and_code_checks':'passed',
           'output_sha256':output_hashes,'matches_packaged_reference':matches,'threadpools':threadpool_info()}
    (out/'reproducibility.json').write_text(json.dumps(audit,indent=2))
    if matches is not None and not all(matches.values()):
        raise RuntimeError('Output differs from packaged reference. See reproducibility.json; do not silently accept changed results.')
    print(json.dumps(overall,indent=2))

if __name__=='__main__': main()
