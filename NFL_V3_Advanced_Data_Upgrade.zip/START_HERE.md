# NFL V3: odds archive and availability data layer

This adds prospective data collection alongside your existing locked V3 EPA model. It does not change its predictions, overwrite your workflows, or claim a higher win rate. No model has been trained on these new injury features yet.

## Install: two files

1. Extract this outer ZIP.
2. Upload `nfl_advanced_data_tools.zip` to the MAIN FOLDER of your existing GitHub repository. Leave this inner ZIP zipped.
3. Create a NEW file named `.github/workflows/nfl-advanced-data.yml`. Paste the complete contents of the included `nfl-advanced-data.yml` and commit.
4. Open Actions > NFL Advanced Data Archive > Run workflow. Keep mode `test` for the first run. This runs all validation tests without an API key or provider usage.
5. In Settings > Secrets and variables > Actions, add a repository secret called `ODDS_API_KEY` with your The Odds API key. Reuse the secret if already configured. Never put the key in a CSV, workflow, commit, or chat.
6. Run the workflow again, choosing `capture`. It makes ONE current-odds request. This uses your provider quota. There is no scheduled polling or historical paid backfill.

If your organization blocks Actions from writing repository contents, the capture can still be downloaded as an artifact, but the archive push will fail. Enable the workflow's repository write permission or use the local commands below. Branch protection can also block archive writes; do not bypass organization policy.

## What a capture produces

- Original provider response, capture time, update times, exact spreads/prices, and response checksum.
- `data/odds.sqlite` on a separate `nfl-data-archive` branch, with an idempotent quote index. Each capture is also saved as raw files under `data/captures/`. Git history preserves earlier commits. This archive is separate from your main code branch; do not merge it into main.
- Availability snapshots, input source records, schedule snapshot and hashes under `data/availability/` on that branch.
- A downloadable `nfl-advanced-data-...` Actions artifact; download and unzip it to inspect CSVs. Artifacts expire after 90 days; the branch archive remains until deleted. A public repository makes these reports public too.
- `matched_quotes.csv` connects provider events to nflverse game IDs. Only unique home/away/kickoff matches are accepted.
- `availability_features.csv` gives one row per team/game, with explicit missing/partial/complete statuses and report ages.
- `game_features.csv` gives one row per game with home/away fields and home-minus-away injury differences, ready to join to a future training dataset using `game_id` and the feature cutoff.
- QB scenario rows and three templates for entering source reports.

Schedule matching fix: canonicalize nflverse LA to LAR for the Rams. Unmatched or ambiguous odds events are recorded in unmatched_events.json and excluded from features instead of stopping the entire capture. If none match, manifest.json reports NO_MATCHED_UPCOMING_GAMES; a green workflow does not establish feature readiness. Started games and stale/future quotes are excluded. Features are only prepared for captures no more than 15 minutes old. The raw capture is archived even if later report processing fails. Empty input files are allowed; the initial run generates templates and records unknown availability rather than inventing starters or healthy rosters.

## Supply QB and injury reports

In the first capture's `availability` folder, find:

- `qb_scenarios_to_fill.csv`
- `injuries_to_fill.csv`
- `injury_coverage_to_fill.csv`

Fill only rows supported by actual pregame reports. Delete unused blank placeholder rows. Upload the completed files to your repository as:

- `nfl_data_inputs/qb_scenarios.csv`
- `nfl_data_inputs/injuries.csv`
- `nfl_data_inputs/injury_coverage.csv`

The empty headers are also provided in this outer package's `inputs` folder. Header-only files work. A file containing unfinished blank rows fails validation. Do not upload the empty templates as completed evidence.

### QB scenarios

Columns: `game_id,team,scenario_set_id,qb_id,start_probability,announced_at_utc,recorded_at_utc,source_url`

Enter a COMPLETE probability distribution for a team's starter at a specific reporting time. All rows for one `scenario_set_id` must have identical timestamps, unique QB IDs, and probabilities summing to 1. Use a new scenario set ID for each update. Use consistent nflverse GSIS QB IDs so these can later join to QB performance history. IDs are not verified against a roster in this release.

For a reliably confirmed starter, use probability 1. For uncertainty, add separate starter/backup rows only when you can justify the probabilities; these are YOUR estimates, not probabilities published or calibrated by this software. The newest complete set replaces earlier sets. Never combine a new starter probability with an old backup row. Blank/unknown information stays missing.

This data layer exports scenario probabilities; it does not yet calculate probability-weighted QB EPA or scenario-weighted cover predictions. The older expected_starters.csv tool remains separate and is not automatically populated from these scenarios.

### Injuries

Columns: `game_id,team,player_id,position,availability_probability,baseline_snap_share,announced_at_utc,recorded_at_utc,source_url`

Use a consistent player ID. Availability is a probability between 0 and 1; baseline snap share is the player's expected share WHEN HEALTHY, also between 0 and 1. Use a documented pregame estimate or earlier completed games to estimate snap share, never the upcoming game's actual snaps. The newest report per player wins. When a player is cleared, append an update with availability 1 rather than deleting history.

Positions: QB; T/OT/G/OG/C/OL; WR/TE; RB/FB; CB/S/FS/SS/DB; DE/DT/NT/LB/ILB/OLB/EDGE/DL; K/P/LS.

For each position group, the feature is:

`sum((1 - availability_probability) * baseline_snap_share)`

An unavailable tackle normally playing 80% of snaps contributes 0.8 OL missing snap equivalents. Two such players contribute 1.6. This is NOT 0.8 points off the spread. There are no invented positional point values, replacement-quality ratings, or fitted injury coefficients. QB injury exposure is exported separately and should not be blindly counted again when adding QB scenario effects to a later model.

### Injury report coverage

Columns: `game_id,team,report_complete,announced_at_utc,recorded_at_utc,source_url`

Use `true` only when the source and your entries cover ALL relevant availability issues for that team/game. Enter it at or after the latest included injury entry. Otherwise use `false` or omit the entry. With a complete report and no affected players, group exposures are zero. With missing/partial coverage, all group exposures are blank, meaning unknown. Partial records are still retained for audit.

All report timestamps need an explicit timezone, preferably UTC: `2026-11-15T17:30:00Z`. Announcement time must precede or equal recording time; both must precede kickoff and the processing cutoff. Unknown teams/games, impossible probabilities, ambiguous simultaneous updates and malformed timestamps fail closed. Sources/times are manually supplied claims, not independently authenticated. Report age is exported; freshness policy must be chosen before model evaluation.

Each manual run collects fresh quotes and builds a new snapshot using the inputs committed at that time. Retain updates in the input ledgers; older games are ignored for the current feature output. A newly created input cannot retroactively change the old branch snapshots. Avoid entering personal medical details; record public football availability only.

## Next model experiment

Keep locked V3 as the benchmark. Collect historical as-of reports from a verified source or accrue prospective records. Fit injury/QB effects only on earlier data, and evaluate additions separately on later games at actual recorded prices. Do not assign hand-picked spread adjustments and call them trained improvements. Previously explored 2020–2025 results remain exploratory. This release provides the collection layer, NOT evidence that injury data raises the model's win percentage.

Before a later model is approved: add prior-game QB performance to each scenario; fit and evaluate scenario-weighted predictions; add replacement quality only with consistent data coverage; fix the prediction time, model settings and selection rule; track out-of-time performance, actual-price ROI, calibration and later prices. Missing inputs must retain their missingness flags.

## Local use (optional)

Extract the inner ZIP into its own tools directory, then run there:

```bash
python -m pip install -r requirements.txt
python verify.py
python -m unittest -v test_data_layer.py
python odds.py --out ../capture_001
python data_layer.py --capture ../capture_001 --archive ../archive --inputs ../nfl_data_inputs --out ../prepared_001
```

Set ODDS_API_KEY in your environment using your computer's secret handling. Reuse the SAME archive directory across captures; use new capture/output folder names. An optional `--schedule games.csv` uses a local nflverse schedule instead of downloading it. The tool expects the standard game_id, home_team, away_team, gameday and gametime columns (US Eastern gametime).

## Validation and limits

See `validation.txt` for executed checks. Tests use clearly synthetic odds and availability records, including a complete local pipeline run. The schedule-matching regression tests cover Rams aliases, mixed valid/unmatched events, ambiguous matches, and a complete zero-match pipeline run. No authenticated provider call, live report verification, GitHub deployment or end-to-end GitHub push was performed here. Your repo still needs the two installation files and API secret. No automated injury provider is connected; reports are manually sourced in this version. No wagers are placed.

Source documentation:
- The Odds API: https://the-odds-api.com/liveapi/guides/v4/
- nflverse schedules: https://github.com/nflverse/nfldata/blob/master/data/games.csv
- nflverse availability: https://nflreadr.nflverse.com/articles/nflverse_data_schedule.html

The odds recorder was adapted from your latest V3 market research package. Existing model files and the earlier failed market-model experiment are not included or changed by this add-on.
